"use strict";
/* SECURITY CONTRACT for DOM writes:
 *   Never use innerHTML / outerHTML / insertAdjacentHTML / document.write
 *   with anything derived from the network, files, nicknames, message
 *   text, reaction emojis, or filenames. Use textContent for text and
 *   setAttribute for attributes. All user strings in this file already
 *   go through .textContent, and the one place we set `.title` uses
 *   textTitle() to keep values out of HTML context.
 */
const enc = new TextEncoder(), dec = new TextDecoder();
const $ = id => document.getElementById(id);
const b64 = b => btoa(String.fromCharCode(...new Uint8Array(b)));
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
const norm = s => s.toLowerCase().trim().split(/\s+/).filter(Boolean);
const WORD = /^[a-z]{4,12}$/;
const genCid = () => hex(crypto.getRandomValues(new Uint8Array(16)));
const textTitle = s => String(s ?? "").slice(0, 500);

async function sha256hex(bytes) {
  const h = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(h)].map(x => x.toString(16).padStart(2, "0")).join("");
}

const FETCH_TIMEOUT  = 30000;
const CHUNK_TIMEOUT  = 60000;
const UPLOAD_TIMEOUT = 120000;
async function fetchWithTimeout(url, opts = {}, timeoutMs = FETCH_TIMEOUT, externalSignal) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(new DOMException("timeout", "TimeoutError")), timeoutMs);
  let onExtAbort = null;
  if (externalSignal) {
    if (externalSignal.aborted) ctrl.abort(externalSignal.reason);
    else {
      onExtAbort = () => ctrl.abort(externalSignal.reason);
      externalSignal.addEventListener("abort", onExtAbort, { once: true });
    }
  }
  try { return await fetch(url, { ...opts, signal: ctrl.signal }); }
  finally {
    clearTimeout(timer);
    if (onExtAbort) externalSignal.removeEventListener("abort", onExtAbort);
  }
}

const idb = () => new Promise((res, rej) => {
  const r = indexedDB.open("e2ee", 1);
  r.onupgradeneeded = () => r.result.createObjectStore("kv");
  r.onsuccess = () => res(r.result);
  r.onerror = () => rej(r.error);
});
const kvGet = async k => { const d = await idb(); return new Promise(r => {
  const q = d.transaction("kv").objectStore("kv").get(k); q.onsuccess = () => r(q.result); }); };
const kvSet = async (k, v) => { const d = await idb(); return new Promise(r => {
  const t = d.transaction("kv", "readwrite"); t.objectStore("kv").put(v, k); t.oncomplete = r; }); };
const kvDel = async k => { const d = await idb(); return new Promise(r => {
  const t = d.transaction("kv", "readwrite"); t.objectStore("kv").delete(k); t.oncomplete = r; }); };

async function saveSelfKey(fid, raw) { await kvSet("selfkey:" + fid, b64(raw)); }
async function loadSelfKey(fid) {
  const v = await kvGet("selfkey:" + fid);
  if (!v) return null;
  return crypto.subtle.importKey("raw", unb64(v), { name: "AES-GCM" }, false, ["decrypt"]);
}

const pubOf = k => ({ kty: k.kty, crv: k.crv, x: k.x, y: k.y });

async function deviceKeys() {
  let d = await kvGet("device") || {};
  if (!d.priv) {
    const kp = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, false, ["sign", "verify"]);
    d.priv = kp.privateKey;
    d.pub = pubOf(await crypto.subtle.exportKey("jwk", kp.publicKey));
    delete d.dhSig;
  }
  if (!d.dhPriv) {
    const kp = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]);
    d.dhPriv = kp.privateKey;
    d.dhPub = pubOf(await crypto.subtle.exportKey("jwk", kp.publicKey));
    delete d.dhSig;
  }
  if (!d.dhSig) {
    const canon = enc.encode(JSON.stringify({
      crv: d.dhPub.crv, kty: d.dhPub.kty, x: d.dhPub.x, y: d.dhPub.y }));
    d.dhSig = b64(await crypto.subtle.sign(
      { name: "ECDSA", hash: "SHA-256" }, d.priv, canon));
  }
  await kvSet("device", d);
  return d;
}
const device = async () => {
  const d = await deviceKeys();
  return { ...d.pub, dh: d.dhPub, dh_sig: d.dhSig };
};

const P = "amber brave calm dusk ember frost gold haze iron jade kite lunar moss nova opal pine".split(" ");
const S = "arrow brook cedar delta eagle field grove harbor island jungle knoll lantern meadow noble orbit peak".split(" ");
const gen = n => [...crypto.getRandomValues(new Uint8Array(n))].map(b => P[b >> 4] + S[b & 15]);

async function wrapAes(dev, epoch, jwk) {
  const pub = await crypto.subtle.importKey("jwk", pubOf(jwk),
    { name: "ECDH", namedCurve: "P-256" }, false, []);
  const bits = await crypto.subtle.deriveBits({ name: "ECDH", public: pub }, dev.dhPriv, 256);
  const hk = await crypto.subtle.importKey("raw", bits, "HKDF", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "HKDF", hash: "SHA-256", salt: new Uint8Array(0), info: enc.encode("e2ee-wrap:" + epoch) },
    hk, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}
async function wrapKey(dev, raw, epoch, jwk) {
  const iv = crypto.getRandomValues(new Uint8Array(12)), k = await wrapAes(dev, epoch, jwk);
  const ct = new Uint8Array(await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: enc.encode("wrap:" + epoch) }, k, raw));
  const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12);
  return b64(out);
}
async function unwrapKey(dev, blob, epoch, jwk) {
  const b = unb64(blob), k = await wrapAes(dev, epoch, jwk);
  return crypto.subtle.decrypt(
    { name: "AES-GCM", iv: b.slice(0, 12), additionalData: enc.encode("wrap:" + epoch) },
    k, b.slice(12));
}
async function derive(label, gid, words, asKey) {
  const base = await crypto.subtle.importKey("raw", enc.encode(words.join(" ")),
    "PBKDF2", false, ["deriveBits", "deriveKey"]);
  const p = { name: "PBKDF2", hash: "SHA-256", iterations: 100000,
              salt: enc.encode(label + ":" + gid.join(" ")) };
  return asKey
    ? crypto.subtle.deriveKey(p, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"])
    : hex(await crypto.subtle.deriveBits(p, base, 256));
}
async function api(path, body, token) {
  const o = { method: body ? "POST" : "GET", headers: { "X-Token": token || "" } };
  if (body) { o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(body); }
  const r = await fetchWithTimeout(path, o, FETCH_TIMEOUT);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error || "request failed"), { status: r.status });
  return j;
}
const showErr = (el, e) => { el.textContent = e.message; el.hidden = false; };
const checkWords = (w, n) => w.length === n && w.every(x => WORD.test(x));
const ensureSecure = () => {
  if (!window.crypto || !crypto.subtle) throw new Error("Web Crypto requires HTTPS or localhost.");
};

function friendlyUploadError(msg) {
  const m = String(msg || "").toLowerCase();
  if (m.includes("bad chunk size"))        return "Server rejected a file chunk (size mismatch). Try again.";
  if (m.includes("chunk integrity"))       return "File was corrupted in transit. Try again.";
  if (m.includes("visibility changed"))    return "Sharing options changed — please try again.";
  if (m.includes("chunk already finalized")) return "This file is already uploaded. Retrying metadata…";
  if (m.includes("quota") || m.includes("disk")) return "Server storage is full. Contact the group admin.";
  if (m.includes("too many concurrent"))   return "Server is busy — try again in a moment.";
  if (m.includes("slow down"))             return "Too many requests — wait a moment and retry.";
  if (m.includes("rotation"))              return "Group key is rotating — wait a moment and retry.";
  if (m.includes("forbidden"))             return "You are not allowed to upload to this group.";
  if (m.includes("unauthorized"))          return "Session expired — rejoin the group.";
  if (m.includes("waiting for the new group key")) return "Waiting for the new group key — try again shortly.";
  if (m.includes("empty") || m.includes("unreadable")) return msg;
  return msg || "Upload failed";
}
function friendlyDownloadError(msg) {
  const m = String(msg || "").toLowerCase();
  if (m.includes("view-only") || m.includes("view only")) return "This file is view-only (no download).";
  if (m.includes("restricted by the admin")) return "Downloads are disabled by the admin for this file.";
  if (m.includes("only the uploader"))       return "Only the uploader can access this file.";
  if (m.includes("no longer available"))     return "This file is no longer on the server.";
  if (m.includes("lost"))                    return "The server lost this file's data — ask the uploader to re-send.";
  if (m.includes("disk is full"))            return "Server is out of space. Try again later.";
  if (m.includes("not allowed"))             return "You are not allowed to access this file.";
  if (m.includes("integrity") || m.includes("hash mismatch")) return "File failed integrity check — retry or re-send.";
  if (m.includes("decryption"))              return "Could not decrypt the file — wrong group key for this epoch.";
  return msg || "Download failed";
}

const ALLOW_UNSIGNED_DH = false;
async function verifyMemberPub(member) {
  const p = member?.pub;
  if (!p || !p.dh) return false;
  if (!p.dh_sig) return ALLOW_UNSIGNED_DH;
  const canon = enc.encode(JSON.stringify({
    crv: p.dh.crv, kty: p.dh.kty, x: p.dh.x, y: p.dh.y }));
  try {
    const vk = await crypto.subtle.importKey("jwk",
      { kty: p.kty, crv: p.crv, x: p.x, y: p.y },
      { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    return await crypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" }, vk, unb64(p.dh_sig), canon);
  } catch { return false; }
}

const MAX_FILE_SIZE    = 32 * 1024 * 1024;
const MAX_STAGED_FILES = 10;
const MAX_STAGED_BYTES = 64 * 1024 * 1024;
const SEND_CHUNK       = 1024 * 1024;

const MAX_VOICE_SECONDS = 300;
const VOICE_BARS        = 32;

const SILENT_WAV = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=";

const pages = {
  async create() {
    const go = $("go"), err = $("err");
    go.onclick = async () => {
      if (go.disabled) return;
      err.hidden = true;
      const nick = $("nick").value.trim();
      try {
        ensureSecure();
        if (!/^[\w .-]{1,24}$/.test(nick)) throw new Error("Nickname: 1–24 letters, numbers, spaces, . _ -");
        if (!$("ack").checked) throw new Error("Please confirm you understand the keys cannot be recovered.");
        go.disabled = true;
        let r, gid, inv, adm;
        for (let t = 0; t < 3 && !r; t++) {
          gid = gen(8); inv = gen(16); adm = gen(32);
          try {
            r = await api("/api/create", { gid, pub: await device(),
              invite_v: await derive("verify-invite", gid, inv),
              admin_v:  await derive("verify-admin",  gid, adm) });
          } catch (e) { if (e.status !== 409) throw e; }
        }
        if (!r) throw new Error("Could not create a unique group, try again.");
        const key = await derive("key", gid, inv, true);
        await kvSet("session", { token: r.token, key, keys: { 0: key }, role: r.role, nick,
                                 memberId: r.member_id, tokenRotatedAt: Date.now(), gid,
                                 groupName: "" });
        $("form").hidden = true; $("result").hidden = false;
        $("o-gid").textContent = gid.join(" ");
        $("o-inv").textContent = inv.join(" ");
        $("o-adm").textContent = adm.join(" ");
        $("o-fp").textContent  = r.fingerprint;
        $("dl").onclick = () => {
          const t = `GROUP ID (8)\n${$("o-gid").textContent}\n\nINVITE KEY (16)\n${$("o-inv").textContent}\n\nADMIN KEY (32, keep private)\n${$("o-adm").textContent}\n`;
          const a = document.createElement("a");
          a.href = URL.createObjectURL(new Blob([t], { type: "text/plain" }));
          a.download = "group-credentials.txt"; a.click();
        };
      } catch (e) { showErr(err, e); go.disabled = false; }
    };
  },

  async join() {
    const go = $("go"), err = $("err");
    go.onclick = async () => {
      if (go.disabled) return;
      err.hidden = true;
      try {
        ensureSecure();
        const gid = norm($("gid").value), inv = norm($("inv").value),
              adm = norm($("adm").value), nick = $("nick").value.trim();
        if (!checkWords(gid, 8))  throw new Error("Group ID must be exactly 8 words.");
        if (!checkWords(inv, 16)) throw new Error("Invite Key must be exactly 16 words.");
        if (adm.length && !checkWords(adm, 32)) throw new Error("Admin Key must be exactly 32 words (or leave empty).");
        if (!/^[\w .-]{1,24}$/.test(nick)) throw new Error("Nickname: 1–24 letters, numbers, spaces, . _ -");
        go.disabled = true;
        const body = { gid, pub: await device(), invite_v: await derive("verify-invite", gid, inv) };
        if (adm.length) body.admin_v = await derive("verify-admin", gid, adm);
        const r = await api("/api/join", body);
        {
          const key = await derive("key", gid, inv, true);
          // Only seed epoch-0 from the invite when the group has never
          // rotated. After a credentials change, epoch-0 messages were
          // encrypted with the OLD invite key (which we don't have); the
          // current epoch key arrives via the wrap mechanism on refresh().
          const keys = {};
          if (!r.epoch || r.epoch === 0) keys[0] = key;
          await kvSet("session", { token: r.token, key, keys, role: r.role, nick,
                                   memberId: r.member_id, tokenRotatedAt: Date.now(), gid,
                                   groupName: r.name || "" });
        }
        location.href = "/chat.html";
      } catch (e) { showErr(err, e); go.disabled = false; }
    };
  },

  async chat() {
    const s = await kvGet("session");
    if (!s) return location.replace("/join-group.html");
    s.keys = s.keys || { 0: s.key };
    s.groupName = s.groupName || "";

    try { localStorage.removeItem("token_sync"); } catch {}

    let bc = null;
    try { bc = new BroadcastChannel("e2ee"); } catch {}
    if (bc) bc.onmessage = (e) => {
      const d = e.data;
      if (d && d.type === "token" && d.token && d.at > (s.tokenRotatedAt || 0)) {
        s.token = d.token; s.tokenRotatedAt = d.at;
        save();
        if (ws) { try { ws.close(); } catch {} }
      }
    };

    if (s.fpCache && !s.fpSeen) {
      s.fpSeen = {};
      for (const [mid, e] of Object.entries(s.fpCache)) {
        s.fpSeen[mid] = { fp: e.fp, lastSeenAt: e.firstSeen || Date.now() };
        if (e.lastChanged) s.fpSeen[mid].lastChangedAt = e.lastChanged;
      }
      delete s.fpCache;
    }
    if (s.fpConfirmed && !s.fpTrusted) {
      s.fpTrusted = {};
      for (const mid of s.fpConfirmed) {
        if (s.fpSeen?.[mid]) s.fpTrusted[mid] = { fp: s.fpSeen[mid].fp, verifiedAt: Date.now() };
      }
      delete s.fpConfirmed;
    }
    s.fpTrusted = s.fpTrusted || {};
    s.fpSeen    = s.fpSeen    || {};

    const dev = await deviceKeys();
    const save = () => kvSet("session", s);

    let ws = null, wsRetry = 0, wsAlive = false, wsHeartbeat = null;
    let lastPong = Date.now();

    const voiceAudios = new Set();
    const fpCache = new WeakMap();

    let audioCtxUnlocked = false;
    async function unlockAudio() {
      if (audioCtxUnlocked) return;
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (AC) {
          const c = new AC();
          const buf = c.createBuffer(1, 1, 22050);
          const src = c.createBufferSource();
          src.buffer = buf;
          src.connect(c.destination);
          src.start(0);
          await c.resume();
          await new Promise(r => setTimeout(r, 40));
          await c.close();
        }
        audioCtxUnlocked = true;
      } catch {}
    }
    document.addEventListener("touchstart", unlockAudio, { once: true, passive: true });
    document.addEventListener("click", unlockAudio, { once: true });

    const qKey = `msgqueue:${s.memberId || "anon"}`;
    const QKEY_IDB = "qkey";
    let msgQueue = [];
    let qCrypto = null;
    async function queueCrypto() {
      if (qCrypto) return qCrypto;
      let raw = await kvGet(QKEY_IDB);
      if (!raw) {
        raw = b64(crypto.getRandomValues(new Uint8Array(32)));
        await kvSet(QKEY_IDB, raw);
      }
      qCrypto = await crypto.subtle.importKey(
        "raw", unb64(raw), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
      return qCrypto;
    }
    async function saveQueue() {
      const safe = msgQueue.map(({ el, ...rest }) => rest);
      try {
        const key = await queueCrypto();
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const pt = enc.encode(JSON.stringify(safe));
        const ct = new Uint8Array(await crypto.subtle.encrypt(
          { name: "AES-GCM", iv, additionalData: enc.encode(qKey) }, key, pt));
        const blob = new Uint8Array(12 + ct.length); blob.set(iv); blob.set(ct, 12);
        await kvSet(qKey, b64(blob));
      } catch {}
    }
    async function loadQueue() {
      try {
        const raw = await kvGet(qKey);
        if (!raw) return [];
        const b = unb64(raw);
        const key = await queueCrypto();
        const pt = await crypto.subtle.decrypt(
          { name: "AES-GCM", iv: b.slice(0, 12), additionalData: enc.encode(qKey) },
          key, b.slice(12));
        const arr = JSON.parse(dec.decode(pt));
        return Array.isArray(arr) ? arr : [];
      } catch { return []; }
    }
    msgQueue = await loadQueue();

    let _postMsg = null;
    async function flushQueue() {
      if (!msgQueue.length) return;
      if (!s.keys[cur] || !_postMsg) return;
      const q = msgQueue;
      msgQueue = [];
      let stop = false;
      for (const item of q) {
        if (stop) { msgQueue.push(item); continue; }
        try {
          const resp = await _postMsg(item.payload);
          if (resp && resp.id && item.el) {
            seen.add(resp.id);
            item.el.dataset.id = resp.id;
            item.el.classList.remove("pending");
            msgEls.set(resp.id, item.el);
            addActions(item.el, resp.id, item.who || "me", item.text || "");
            updateReactionsUI(resp.id);
          }
        } catch (e) {
          if (!e.status || e.status >= 500 || e.status === 429) {
            stop = true;
            msgQueue.push(item);
          }
        }
      }
      saveQueue();
      if (msgQueue.length === 0) {
        setBanner("", null);
        poll();
      }
    }
    function enqueueMsg(payload, el, who, text) {
      msgQueue.push({ payload, at: Date.now(), el, who, text });
      saveQueue();
    }

    if (!document.getElementById("__fp_styles")) {
      const st = document.createElement("style");
      st.id = "__fp_styles";
      st.textContent = `
        .msg.fp-changed{ border-color:var(--bad); background:rgba(255,138,122,.10) }
        .msg.fp-changed::after{ content:"⚠ signing key changed — verify before trusting"; display:block;
                                margin-top:6px; font-size:11px; color:var(--bad) }
        .fp-btn{ background:transparent; border:0; cursor:pointer; font-size:12px; opacity:.65;
                 padding:0 4px; margin:0 0 0 4px; vertical-align:baseline }
        .fp-btn:hover{ opacity:1 }
        .msg.pending{ opacity:.7 }
        .msg.pending::after{ content:"⏳"; font-size:11px; color:var(--dim); margin-left:4px }
      `;
      document.head.append(st);
    }

    let after = 0, me = null, cur = 0, members = {};
    let filePolicy = "admin";
    const nicks = s.nicks || {};
    const nickPinned = new Set(s.nickPinned || []);
    const vk = {}, seen = new Set();
    const box = $("msgs"), CH = SEND_CHUNK, MAXCH = 32;
    const PREV = ["image/png","image/jpeg","image/gif","image/webp","video/mp4","video/webm"];
    const fmt = n => n < 1024 ? n + " B"
                  : n < 1048576 ? (n/1024).toFixed(1)+" KB"
                  : (n/1048576).toFixed(1)+" MB";

    let onlineSet = new Set(), loaded = false;
    const typingTimers = {}, lastTypingAt = [0];
    const reactionsMap = new Map(), msgEls = new Map();
    let replyTo = null;
    const blobUrls = new Set();
    const fpWarned = new Set();

    const setDot = state => { const d = $("dot"); if (d) d.className = "dot " + state; };
    const setStatus = t => { const el = $("status"); if (el) el.textContent = t; };
    const updateGroupName = () => {
      const el = $("groupname");
      if (el) el.textContent = s.groupName || "Private group";
    };
    function setBanner(text, retry) {
      const b = $("banner"); if (!b) return;
      b.textContent = ""; b.hidden = !text;
      if (!text) return;
      const sp = document.createElement("span"); sp.textContent = text; sp.style.flex = "1"; b.append(sp);
      if (retry) {
        const btn = document.createElement("button"); btn.textContent = "Retry";
        btn.onclick = retry; b.append(btn);
      }
    }
    function releaseBlobUrls() {
      for (const u of blobUrls) { try { URL.revokeObjectURL(u); } catch {} }
      blobUrls.clear();
      for (const a of voiceAudios) {
        try { a.pause(); a.src = ""; a.load(); } catch {}
      }
      voiceAudios.clear();
    }
    const saveNicks = () => { s.nicks = nicks; s.nickPinned = [...nickPinned]; save(); };

    async function memberSigningFp(pub) {
      if (!pub || typeof pub !== "object") return "";
      if (fpCache.has(pub)) return fpCache.get(pub);
      const { crv, kty, x, y } = pub;
      if (typeof crv !== "string" || typeof kty !== "string" ||
          typeof x !== "string" || typeof y !== "string") return "";
      const canon = `{"crv": "${crv}", "kty": "${kty}", "x": "${x}", "y": "${y}"}`;
      const h = await crypto.subtle.digest("SHA-256", enc.encode(canon));
      const fp = [...new Uint8Array(h)].map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
      fpCache.set(pub, fp);
      return fp;
    }

    function fpStatus(mid) {
      const t = s.fpTrusted[mid];
      if (!t) return "unverified";
      const seenFp = s.fpSeen[mid]?.fp;
      if (!seenFp) return "unverified";
      return String(t.fp).toLowerCase() === String(seenFp).toLowerCase() ? "trusted" : "changed";
    }

    async function checkAndRecordFp(mid) {
      const m = members[mid];
      if (!m) return "";
      const fp = await memberSigningFp(m.pub);
      if (!fp) return "";
      const prev = s.fpSeen[mid];
      const now = Date.now();
      if (!prev) {
        s.fpSeen[mid] = { fp, lastSeenAt: now };
        save();
      } else if (String(prev.fp).toLowerCase() !== String(fp).toLowerCase()) {
        prev.fp = fp;
        prev.lastSeenAt = now;
        prev.lastChangedAt = now;
        save();
        if (!fpWarned.has(mid)) {
          fpWarned.add(mid);
          const name = nicks[mid] || mid;
          setBanner(`⚠️ ${name}'s signing key changed — tap 🔐 on any of their messages to verify the new fingerprint`, null);
        }
      } else {
        if (!prev.lastSeenAt || now - prev.lastSeenAt > 60_000) {
          prev.lastSeenAt = now;
          save();
        }
      }
      return fp;
    }

    function applyFpClass(el, mid) {
      const st = fpStatus(mid);
      el.classList.toggle("fp-changed", st === "changed");
    }

    const isAdmin = mid => !!(members[mid] && members[mid].role === "admin");
    const crown = mid => isAdmin(mid) ? "👑 " : "";
    const displayName = mid => crown(mid) + (nicks[mid] || "unknown");

    function setFilePolicy(p) { if (!p || p === filePolicy) return; filePolicy = p; refreshFilePolicies(); updatePolicyUI(); }

    function applyFilePolicy(el) {
      if (!el._fileData || !el._fileUI) return;
      const f = el._fileData;
      const isOwner = el.classList.contains("me");
      const isAdm = s.role === "admin";
      const canView = f.vis === "self" ? isOwner : true;
      let canDl;
      if (f.vis === "self") canDl = isOwner;
      else if (f.vis === "view") canDl = false;
      else canDl = isOwner || isAdm || filePolicy === "everyone";

      el._fileUI.pv.hidden = !(canView && PREV.includes(f.type));
      el._fileUI.dl.hidden = !canDl;
      el._fileUI.actions.hidden = !canView;
      if (!canView) {
        el._fileUI.note.hidden = false;
        el._fileUI.note.className = "file-note private";
        el._fileUI.note.textContent = "🔒 Only the uploader can view this file";
        return;
      }
      if (f.vis === "self") {
        el._fileUI.note.hidden = false;
        el._fileUI.note.className = "file-note private";
        el._fileUI.note.textContent = isOwner ? "🔒 Only you can access this file" : "";
        if (!isOwner) el._fileUI.note.hidden = true;
      } else if (f.vis === "view") {
        el._fileUI.note.hidden = false;
        el._fileUI.note.className = "file-note view-only";
        el._fileUI.note.textContent = isOwner
          ? "👁 You shared this as view-only (no download)"
          : "👁 View only (no download)";
      } else {
        if (!canDl) {
          el._fileUI.note.hidden = false;
          el._fileUI.note.className = "file-note";
          el._fileUI.note.textContent = filePolicy === "owner"
            ? "🔒 Only the uploader or admins can download"
            : "🔒 Only admins can download files";
        } else el._fileUI.note.hidden = true;
      }
    }
    function refreshFilePolicies() {
      for (const [, el] of msgEls) if (el._fileData) applyFilePolicy(el);
    }
    function updatePolicyUI() {
      document.querySelectorAll(".policy-options [data-policy]").forEach(b => {
        b.classList.toggle("selected", b.dataset.policy === filePolicy);
      });
      document.querySelectorAll('input[name="filepol"]').forEach(r => {
        r.checked = r.value === filePolicy;
      });
    }
    function maybeShowPolicyBanner() {
      if (s.role !== "admin" || !me) return;
      const key = "policy_asked_" + me;
      if (sessionStorage.getItem(key)) return;
      const b = $("policy-banner"); if (!b) return;
      b.hidden = false; updatePolicyUI();
    }
    async function changePolicy(policy) {
      try {
        await api("/api/admin/set-policy", { policy }, s.token);
        setFilePolicy(policy);
        const b = $("policy-banner"); if (b) b.hidden = true;
        if (me) sessionStorage.setItem("policy_asked_" + me, "1");
        setStatus("Download policy: " + policy);
      } catch (e) { setStatus(e.message); }
    }
    document.querySelectorAll(".policy-options [data-policy]").forEach(b => {
      b.onclick = () => changePolicy(b.dataset.policy);
    });
    const pd = $("policy-dismiss");
    if (pd) pd.onclick = () => {
      const b = $("policy-banner"); if (b) b.hidden = true;
      if (me) sessionStorage.setItem("policy_asked_" + me, "1");
    };
    document.querySelectorAll('input[name="filepol"]').forEach(r => {
      r.onchange = () => { if (r.checked) changePolicy(r.value); };
    });

    function updatePresence() {
      for (const mid of Object.keys(typingTimers)) {
        if (!onlineSet.has(mid)) { clearTimeout(typingTimers[mid]); delete typingTimers[mid]; }
      }
      refreshTyping();
      const el = $("presence");
      if (el) el.textContent = `${onlineSet.size}/${Object.keys(members).length || 0} online`;
    }
    function refreshTyping() {
      const el = $("typing"); if (!el) return;
      const ids = Object.keys(typingTimers);
      if (!ids.length) { el.hidden = true; el.textContent = ""; return; }
      const names = ids.map(displayName);
      el.textContent = names.join(", ") + (names.length === 1 ? " is typing…" : " are typing…");
      el.hidden = false;
    }
    function showTyping(mid) {
      if (mid === me) return;
      clearTimeout(typingTimers[mid]);
      typingTimers[mid] = setTimeout(() => { delete typingTimers[mid]; refreshTyping(); }, 4000);
      refreshTyping();
    }
    function clearTyping(mid) { if (typingTimers[mid]) { clearTimeout(typingTimers[mid]); delete typingTimers[mid]; refreshTyping(); } }

    function applyReaction(msgId, emoji, mid) {
      if (!reactionsMap.has(msgId)) reactionsMap.set(msgId, {});
      const r = reactionsMap.get(msgId);
      if (!r[emoji]) r[emoji] = new Set();
      r[emoji].add(mid); updateReactionsUI(msgId);
    }
    function updateReactionsUI(msgId) {
      const el = msgEls.get(msgId); if (!el) return;
      let rxEl = el.querySelector(".reactions");
      if (!rxEl) { rxEl = document.createElement("div"); rxEl.className = "reactions"; el.append(rxEl); }
      rxEl.textContent = "";
      const r = reactionsMap.get(msgId) || {};
      for (const [emoji, mids] of Object.entries(r)) {
        if (!mids.size) continue;
        const chip = document.createElement("span");
        chip.className = "rchip" + (mids.has(me) ? " mine" : "");
        chip.textContent = `${emoji} ${mids.size}`;
        chip.title = textTitle([...mids].map(displayName).join(", "));
        chip.onclick = () => sendReaction(msgId, emoji);
        rxEl.append(chip);
      }
    }
    async function sendReaction(msgId, emoji) {
      try { await postMsg({ n: s.nick, react: { m: msgId, e: emoji } }, { noReply: true }); }
      catch (e) { setStatus(e.message); }
    }
    function renderReplyPreview() {
      const el = $("reply-preview"); if (!el) return;
      if (!replyTo) { el.hidden = true; return; }
      el.hidden = false;
      $("reply-text").textContent = `Replying to ${replyTo.who}: ${String(replyTo.p || "").slice(0, 60)}`;
    }
    function setReply(msgId, who, preview) {
      replyTo = { id: msgId, who, p: String(preview || "").slice(0, 200) };
      renderReplyPreview(); $("text").focus();
    }
    $("reply-cancel").onclick = () => { replyTo = null; renderReplyPreview(); };

    const aad = (f, i) => enc.encode(f.id + ":" + i + ":" + f.chunks + ":" + f.e);
    const cleanName = n => String(n).replace(/[\\/:*?"<>|\x00-\x1f]/g, "_").slice(0, 120) || "file";

    function fileIcon(type, name) {
      if (type.startsWith("image/")) return "🖼";
      if (type.startsWith("video/")) return "🎥";
      if (type.startsWith("audio/")) return "🎤";
      if (/pdf/.test(type) || /\.pdf$/i.test(name)) return "📄";
      if (/zip|rar|7z|tar|gzip|x-compressed/.test(type) || /\.(zip|rar|7z|tar|gz)$/i.test(name)) return "🗜";
      if (type.startsWith("text/")) return "📝";
      if (/word|document|msword/.test(type) || /\.(docx?)$/i.test(name)) return "📘";
      if (/sheet|excel/.test(type) || /\.(xlsx?|csv)$/i.test(name)) return "📗";
      if (/presentation|powerpoint/.test(type) || /\.(pptx?)$/i.test(name)) return "📙";
      return "📎";
    }

    function addMsgBubble(cls, who, ts, msgId, replyData, senderMid) {
      const d = document.createElement("div"); d.className = "msg " + cls;
      if (msgId != null) d.dataset.id = msgId;
      const h = document.createElement("b");
      h.textContent = who + " · " + new Date(ts * 1000).toLocaleTimeString();

      if (senderMid) {
        const status = fpStatus(senderMid);
        const btn = document.createElement("button");
        btn.type = "button"; btn.className = "fp-btn";
        btn.textContent = status === "trusted" ? " 🔐✓" : status === "changed" ? " 🔐⚠" : " 🔐";
        btn.title = textTitle(status === "trusted" ? "Fingerprint verified"
                  : status === "changed" ? "Signing key changed — click to verify"
                  : "Fingerprint not verified — click to view");
        btn.style.color = status === "trusted" ? "var(--acc)"
                        : status === "changed" ? "var(--bad)"
                        : "var(--warn)";
        btn.onclick = async (e) => {
          e.stopPropagation();
          const st = fpStatus(senderMid);
          const name = nicks[senderMid] || senderMid;
          const currentFp = await memberSigningFp(members[senderMid]?.pub);
          const trusted = s.fpTrusted[senderMid];

          if (st === "trusted") {
            if (confirm(
              `Signing-key fingerprint for ${name}\n\n` +
              `${currentFp}\n\n` +
              `✓ Verified on this device at ${new Date(trusted.verifiedAt).toLocaleString()}\n\n` +
              `Un-verify this fingerprint?`
            )) {
              delete s.fpTrusted[senderMid];
              save();
              for (const [, el] of msgEls) if (el.dataset.sender === senderMid) applyFpClass(el, senderMid);
            }
            return;
          }

          if (st === "changed") {
            if (confirm(
              `⚠️ ${name}'s signing key CHANGED\n\n` +
              `Previously trusted: ${trusted.fp}\n` +
              `Current:            ${currentFp}\n\n` +
              `If unexpected, they may be an impersonator or their device compromised.\n\n` +
              `Trust the new fingerprint?`
            )) {
              s.fpTrusted[senderMid] = { fp: currentFp, verifiedAt: Date.now() };
              save();
              fpWarned.delete(senderMid);
              setBanner("", null);
              for (const [, el] of msgEls) if (el.dataset.sender === senderMid) applyFpClass(el, senderMid);
            }
            return;
          }

          if (confirm(
            `Signing-key fingerprint for ${name}\n\n` +
            `${currentFp}\n\n` +
            `⚠ Not yet verified. Compare this value in person or over a trusted channel.\n\n` +
            `Mark as trusted on this device?`
          )) {
            s.fpTrusted[senderMid] = { fp: currentFp, verifiedAt: Date.now() };
            save();
            for (const [, el] of msgEls) if (el.dataset.sender === senderMid) applyFpClass(el, senderMid);
          }
        };
        h.append(btn);
        if (status === "changed") d.classList.add("fp-changed");
      }

      d.append(h);
      if (replyData) {
        const q = document.createElement("div"); q.className = "quote";
        q.textContent = `↩ ${replyData.who}: ${String(replyData.p || "").slice(0, 80)}`;
        d.append(q);
      }
      if (senderMid) d.dataset.sender = senderMid;
      box.append(d); return d;
    }
    function addActions(d, msgId, who, preview) {
      const a = document.createElement("div"); a.className = "msg-actions";
      const replyBtn = document.createElement("button"); replyBtn.className = "alt small"; replyBtn.textContent = "↩"; replyBtn.title = "Reply";
      replyBtn.onclick = () => setReply(msgId, who, preview);
      const emojiBtn = document.createElement("button"); emojiBtn.className = "alt small"; emojiBtn.textContent = "😀"; emojiBtn.title = "React";
      emojiBtn.onclick = () => {
        const old = d.querySelector(".emoji-picker"); if (old) { old.remove(); return; }
        const p = document.createElement("div"); p.className = "emoji-picker";
        for (const e of ["👍","❤️","😂","😮","😢","🎉"]) {
          const b = document.createElement("button"); b.textContent = e;
          b.onclick = () => { sendReaction(msgId, e); p.remove(); };
          p.append(b);
        }
        d.append(p);
      };
      a.append(replyBtn, emojiBtn); d.append(a);
    }
    function addText(cls, who, text, ts, msgId, replyData, senderMid) {
      const d = addMsgBubble(cls, who, ts, msgId, replyData, senderMid);
      const p = document.createElement("p"); p.textContent = text; d.append(p);
      if (msgId != null) { addActions(d, msgId, who, text); msgEls.set(msgId, d); updateReactionsUI(msgId); }
      box.scrollTop = box.scrollHeight;
      return d;
    }
    function addUnverified(ts, msgId) {
      const d = addMsgBubble("bad", "unknown ⚠️ signature invalid", ts, msgId, null, null);
      d.classList.add("unverified");
      const p = document.createElement("p");
      p.style.color = "var(--bad)";
      p.textContent = "[This message failed signature verification and was not displayed]";
      d.append(p);
      if (msgId != null) { addActions(d, msgId, "unknown", "[unverified]"); msgEls.set(msgId, d); }
      box.scrollTop = box.scrollHeight;
    }

    async function fetchFile(f, onp, opts = {}, signal) {
      let key;
      if (f.vis === "self") {
        key = await loadSelfKey(f.id);
        if (!key) throw new Error("This private file's key is not on this device.");
      } else {
        key = s.keys[f.e];
        if (!key) throw new Error("Group key missing for this file's epoch.");
      }
      const dlFlag = opts.download ? "&download=1" : "";
      const parts = []; let totalBytes = 0;
      for (let i = 0; i < f.chunks; i++) {
        if (i > 0) await new Promise(r => setTimeout(r, 100));
        let r = null;
        for (let attempt = 0; attempt < 4; attempt++) {
          try {
            r = await fetchWithTimeout(
              `/api/file?fid=${f.id}&idx=${i}${dlFlag}`,
              { headers: { "X-Token": s.token } }, CHUNK_TIMEOUT, signal);
          } catch (netErr) {
            if (signal?.aborted || netErr?.name === "AbortError") throw netErr;
            r = null;
          }
          if (r && r.ok) break;
          if (r && r.status === 403) throw new Error(friendlyDownloadError((await r.json().catch(()=>({}))).error));
          if (r && r.status === 404) throw new Error(friendlyDownloadError("File is no longer available."));
          if (r && r.status === 410) throw new Error(friendlyDownloadError("The server lost this file's data."));
          if (r && r.status === 507) throw new Error(friendlyDownloadError("server disk is full"));
          if (r && r.status === 429) { await new Promise(res => setTimeout(res, 5000)); continue; }
          if (r && r.status >= 500) throw new Error("Server error while downloading. Please try again later.");
          await new Promise(res => setTimeout(res, 400 * (1 << attempt)));
        }
        if (!r || !r.ok) throw new Error("Could not download the file — check your connection and retry.");
        let rawBuf;
        try { rawBuf = await r.arrayBuffer(); }
        catch (readErr) {
          if (signal?.aborted) throw new Error("Cancelled");
          throw new Error("Connection interrupted while downloading. Please retry.");
        }
        if (rawBuf.byteLength < 28) throw new Error("Received a corrupted chunk. Please retry.");
        const b = new Uint8Array(rawBuf);
        const advHash = r.headers.get("X-Chunk-SHA256");
        if (!advHash) {
          throw new Error(
            `Chunk ${i + 1}/${f.chunks} missing integrity hash — refusing unverified data. ` +
            `Ask the admin to run the server with REQUIRE_CHUNK_HASH=1.`);
        }
        const computed = await sha256hex(b);
        if (computed !== advHash.toLowerCase())
          throw new Error(`Chunk ${i + 1}/${f.chunks} failed integrity check (hash mismatch).`);
        let plain;
        try {
          plain = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: b.slice(0, 12), additionalData: aad(f, i) }, key, b.slice(12));
        } catch {
          throw new Error(`Could not decrypt chunk ${i+1}/${f.chunks}. File may be corrupted or you lack this epoch's key.`);
        }
        const chunk = new Uint8Array(plain);
        parts.push(chunk); totalBytes += chunk.length;
        onp(Math.round((i + 1) / f.chunks * 100));
      }
      if (totalBytes !== f.size)
        throw new Error(`File size mismatch (expected ${f.size} B, got ${totalBytes} B).`);
      return parts;
    }

    function fmtDur(s) {
      s = Math.max(0, Math.floor(Number(s) || 0));
      return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
    }

    function voiceBars(id, n) {
      let h = 0;
      for (let i = 0; i < id.length; i++) h = ((h << 5) - h + id.charCodeAt(i)) | 0;
      const out = [];
      for (let i = 0; i < n; i++) {
        h = (Math.imul(h, 1664525) + 1013904223) | 0;
        out.push(0.2 + ((h >>> 0) % 1000) / 1000 * 0.8);
      }
      return out;
    }

    function renderVoice(d, f) {
      d.classList.add("voice-msg");
      const wrap = document.createElement("div"); wrap.className = "voice";
      const play = document.createElement("button");
      play.type = "button"; play.className = "voice-play";
      play.textContent = "▶"; play.title = "Play voice message";
      play.setAttribute("aria-label", "Play voice message");

      const wave = document.createElement("div"); wave.className = "voice-wave";
      for (const h of voiceBars(f.id, VOICE_BARS)) {
        const b = document.createElement("span");
        b.style.height = Math.round(h * 26) + "px";
        wave.append(b);
      }
      const time = document.createElement("span"); time.className = "voice-time";
      time.textContent = fmtDur(f.dur);

      wrap.append(play, wave, time);
      d.append(wrap);

      let audio = null, loading = false;
      const totalDur = () =>
        (audio && isFinite(audio.duration) && audio.duration > 0) ? audio.duration
                                                                  : Number(f.dur) || 0;
      const setProgress = p => {
        const bs = wave.children, n = bs.length;
        const k = Math.round(Math.max(0, Math.min(1, p)) * n);
        for (let i = 0; i < n; i++) bs[i].classList.toggle("played", i < k);
      };

      play.onclick = async () => {
        if (loading) return;
        if (!audio) {
          audio = new Audio();
          audio.src = SILENT_WAV;
          try { await audio.play(); } catch {}
          try { audio.pause(); audio.currentTime = 0; } catch {}
          voiceAudios.add(audio);

          loading = true; play.disabled = true; play.textContent = "…";
          try {
            const parts = await fetchFile(f, pct => {
              if (pct < 100) play.textContent = pct + "%";
            }, {});
            const blob = new Blob(parts, { type: f.type || "audio/webm" });
            const url = URL.createObjectURL(blob);
            blobUrls.add(url);
            audio.src = url;
            audio.preload = "auto";
            audio.ontimeupdate = () => {
              const T = totalDur();
              if (T > 0) setProgress(audio.currentTime / T);
            };
            audio.onloadedmetadata = () => {
              if (isFinite(audio.duration) && audio.duration > 0) {
                time.textContent = fmtDur(audio.duration);
              }
            };
            audio.onended = () => {
              play.textContent = "▶";
              setProgress(0);
              try { audio.currentTime = 0; } catch {}
            };
            audio.onerror = () => { play.textContent = "▶"; time.textContent = "err"; };
          } catch (e) {
            play.disabled = false; play.textContent = "▶";
            time.textContent = "err";
            setStatus(e.message || "Could not load voice message");
            loading = false;
            return;
          }
          play.disabled = false;
          play.textContent = "▶";
          loading = false;
        }
        for (const a of voiceAudios) {
          if (a !== audio && !a.paused) { try { a.pause(); } catch {} }
        }
        if (audio.paused) {
          try { await audio.play(); play.textContent = "⏸"; }
          catch (e) { setStatus("Playback blocked: " + e.message); }
        } else {
          audio.pause(); play.textContent = "▶";
        }
      };

      wave.onclick = (e) => {
        if (!audio) return;
        const T = totalDur();
        if (!T) return;
        const r = wave.getBoundingClientRect();
        const p = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
        try { audio.currentTime = p * T; setProgress(p); } catch {}
      };
    }

    function addFile(cls, who, f, ts, msgId, replyData, senderMid) {
      const d = addMsgBubble(cls, who, ts, msgId, replyData, senderMid);

      if (f.voice) {
        renderVoice(d, f);
        if (msgId != null) {
          addActions(d, msgId, who, "🎤 voice message");
          msgEls.set(msgId, d); updateReactionsUI(msgId);
        }
        box.scrollTop = box.scrollHeight;
        return;
      }

      const prefix = f.vis === "self" ? "🔒 " : f.vis === "view" ? "👁 " : "";
      const p = document.createElement("p");
      p.textContent = prefix + fileIcon(f.type, f.name) + " " + f.name + " (" + fmt(f.size) + ")";
      d.append(p);

      const actionsEl = document.createElement("div"); actionsEl.className = "file-actions";
      const st = document.createElement("small"),
            dl = document.createElement("button"),
            pv = document.createElement("button"),
            out = document.createElement("div");
      dl.textContent = "Download"; pv.textContent = "Preview";
      dl.className = pv.className = "alt small";
      pv.hidden = !PREV.includes(f.type);

      const run = async (preview) => {
        dl.disabled = pv.disabled = true;
        st.textContent = " downloading…";
        try {
          const parts = await fetchFile(f, n => st.textContent = " decrypting " + n + "%",
                                        { download: !preview });
          const blob = new Blob(parts, { type: preview ? f.type : "application/octet-stream" });
          const url = URL.createObjectURL(blob);
          if (preview) {
            blobUrls.add(url);
            out.textContent = "";
            const el = document.createElement(f.type.startsWith("video") ? "video" : "img");
            el.src = url;
            if (el.tagName === "VIDEO") el.controls = true;
            out.append(el);
          } else {
            const a = document.createElement("a"); a.href = url; a.download = f.name; a.click();
            setTimeout(() => URL.revokeObjectURL(url), 60000);
          }
          st.textContent = " ✓ integrity verified";
        } catch (e) {
          st.textContent = " " + friendlyDownloadError(e.message || "failed");
        }
        dl.disabled = pv.disabled = false;
      };
      dl.onclick = () => run(false);
      pv.onclick = () => run(true);
      actionsEl.append(dl, pv, st, out); d.append(actionsEl);

      const noteEl = document.createElement("small"); noteEl.className = "file-note"; noteEl.hidden = true;
      d.append(noteEl);
      d._fileData = f;
      d._fileUI = { actions: actionsEl, dl, pv, note: noteEl };
      applyFilePolicy(d);

      if (msgId != null) {
        addActions(d, msgId, who, "[file] " + f.name);
        msgEls.set(msgId, d); updateReactionsUI(msgId);
      }
      box.scrollTop = box.scrollHeight;
    }

    const validFile = f => {
      if (!f || typeof f !== "object") return false;
      if (!Number.isInteger(f.e) || f.e < 0) return false;
      if (!s.keys[f.e]) return false;
      if (typeof f.id !== "string" || !/^[0-9a-f]{32}$/.test(f.id)) return false;
      if (!Number.isInteger(f.chunks) || f.chunks < 1 || f.chunks > MAXCH) return false;
      if (typeof f.size !== "number" || !Number.isFinite(f.size) ||
          f.size <= 0 || f.size > MAXCH * CH) return false;
      if (typeof f.name !== "string" || f.name.length === 0 || f.name.length > 200) return false;
      if (f.type !== undefined && (typeof f.type !== "string" || f.type.length > 60)) return false;
      if (f.vis !== undefined && f.vis !== "all" && f.vis !== "view" && f.vis !== "self") return false;
      if (f.voice !== undefined && f.voice !== true) return false;
      if (f.dur !== undefined) {
        if (typeof f.dur !== "number" || !Number.isFinite(f.dur) ||
            f.dur < 0 || f.dur > 600) return false;
      }
      return true;
    };

    function pruneOldKeys(currentEpoch) {
      const KEEP = 100;
      const all = Object.keys(s.keys).map(Number).filter(n => Number.isInteger(n) && n >= 0);
      const drop = all.filter(e => e < currentEpoch - KEEP);
      if (!drop.length) return;
      for (const e of drop) delete s.keys[e];
      save();
    }

    let _refreshPromise = null;
    function refresh() {
      if (_refreshPromise) return _refreshPromise;
      _refreshPromise = (async () => {
        try { await refreshInner(); }
        finally { _refreshPromise = null; }
      })();
      return _refreshPromise;
    }
    async function refreshInner() {
      const st = await api("/api/state", null, s.token);
      cur = st.epoch; members = {}; st.members.forEach(m => members[m.id] = m);
      for (const mid of Object.keys(members)) await checkAndRecordFp(mid);
      if (st.file_policy) setFilePolicy(st.file_policy);
      if (st.name !== undefined) { s.groupName = st.name || ""; save(); updateGroupName(); }
      if (Array.isArray(st.online)) { onlineSet = new Set(st.online); updatePresence(); }
      for (const w of st.wraps) {
        if (s.keys[w.epoch]) continue;
        const f = members[w.from];
        if (!f || f.role !== "admin" || !f.pub.dh) continue;
        if (!(await verifyMemberPub(f))) { console.warn("dh_sig invalid for", w.from); continue; }
        try {
          s.keys[w.epoch] = await crypto.subtle.importKey(
            "raw", await unwrapKey(dev, w.blob, w.epoch, f.pub.dh), "AES-GCM",
            s.role === "admin", ["encrypt","decrypt"]);
        } catch {}
      }
      pruneOldKeys(cur);
      await save();
      if (s.role !== "admin") return;
      try {
        if (st.rot) {
          const e = cur + 1, raw = crypto.getRandomValues(new Uint8Array(32));
          const wraps = [];
          for (const m of st.members) {
            if (!m.pub.dh) continue;
            if (!(await verifyMemberPub(m))) {
              console.warn("[rotate] skipping member with bad dh_sig:", m.id);
              continue;
            }
            wraps.push({ member_id: m.id, blob: await wrapKey(dev, raw, e, m.pub.dh) });
          }
          let rotResp = null;
          try {
            rotResp = await api("/api/rotate", { epoch: e, wraps }, s.token);
          } catch (re) {
            if (re && re.status === 409) {
              rotResp = { already: true, epoch: e };
            } else { throw re; }
          }
          if (rotResp && rotResp.already) {
            // Another admin/tab already committed this epoch with a
            // different key. Fetch fresh state and unwrap the WINNER's key
            // so we don't diverge from everyone else's wraps.
            const st2 = await api("/api/state", null, s.token);
            for (const w of st2.wraps) {
              if (s.keys[w.epoch]) continue;
              const f = members[w.from];
              if (!f || f.role !== "admin" || !f.pub.dh) continue;
              if (!(await verifyMemberPub(f))) continue;
              try {
                s.keys[w.epoch] = await crypto.subtle.importKey(
                  "raw", await unwrapKey(dev, w.blob, w.epoch, f.pub.dh), "AES-GCM",
                  s.role === "admin", ["encrypt","decrypt"]);
              } catch {}
            }
            cur = st2.epoch; await save();
          } else {
            s.keys[e] = await crypto.subtle.importKey("raw", raw, "AES-GCM", true, ["encrypt","decrypt"]);
            cur = e; await save();
          }
        } else if (st.missing.length && s.keys[cur]) {
          const raw = new Uint8Array(await crypto.subtle.exportKey("raw", s.keys[cur]));
          const wraps = [];
          for (const id of st.missing) {
            const m = members[id];
            if (!m || !m.pub.dh) continue;
            if (!(await verifyMemberPub(m))) continue;
            wraps.push({ member_id: id, blob: await wrapKey(dev, raw, cur, m.pub.dh) });
          }
          if (wraps.length) await api("/api/wrap", { epoch: cur, wraps }, s.token);
        }
      } catch (err) {
        console.warn("[rotate] failed:", err.message);
        setBanner("⚠️ Key rotation blocked — " + err.message + ". Check Admin panel for members with invalid DH signatures.", null);
      }
    }
    async function verify(mid, data, sig) {
      if (!members[mid]) await refresh().catch(() => {});
      const m = members[mid]; if (!m) return false;
      try {
        vk[mid] = vk[mid] || await crypto.subtle.importKey(
          "jwk", pubOf(m.pub), { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
        return await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" },
                                          vk[mid], unb64(sig), data);
      } catch { return false; }
    }
    async function postMsg(obj, opts = {}) {
      const key = s.keys[cur]; if (!key) throw new Error("Waiting for the new group key…");
      const cid = obj.cid; if (cid) delete obj.cid;
      if (!opts.noReply && replyTo) { obj.r = replyTo; replyTo = null; renderReplyPreview(); }
      const e = cur, iv = crypto.getRandomValues(new Uint8Array(12));
      const raw = enc.encode(JSON.stringify(obj));
      const pt = new Uint8Array(Math.ceil((raw.length + 1) / 256) * 256).fill(32); pt.set(raw);
      const ct = b64(await crypto.subtle.encrypt(
        { name: "AES-GCM", iv, additionalData: enc.encode("v2:" + e) }, key, pt));
      const ivb = b64(iv);
      const sigInput = cid
        ? enc.encode(`${e}:${ivb}:${ct}:${cid}`)
        : enc.encode(`${e}:${ivb}:${ct}`);
      const sig = await crypto.subtle.sign(
        { name: "ECDSA", hash: "SHA-256" }, dev.priv, sigInput);
      const body = { iv: e + ":" + ivb, ct: ct + "." + b64(sig) };
      if (cid) body.cid = cid;
      return api("/api/send", body, s.token);
    }
    _postMsg = postMsg;

    const uploads = new Map();
    const uploadsEl = $("uploads");
    function renderUploadRow(name, id, vis) {
      const row = document.createElement("div"); row.className = "prow"; row.dataset.id = id;
      const icon = vis === "self" ? "🔒" : vis === "view" ? "👁" : "";
      const nameEl = document.createElement("span");
      nameEl.textContent = (icon ? icon + " " : "") + name;
      const prog = document.createElement("progress"); prog.max = 100; prog.value = 0;
      const pct = document.createElement("small"); pct.textContent = "0%";
      const cancel = document.createElement("button"); cancel.className = "alt"; cancel.textContent = "✕"; cancel.title = "Cancel";
      const retry = document.createElement("button"); retry.className = "alt"; retry.textContent = "⟳"; retry.title = "Retry"; retry.hidden = true;
      row.append(nameEl, prog, pct, cancel, retry);
      uploadsEl.append(row); uploadsEl.hidden = false;
      return { row, prog, pct, cancel, retry };
    }

    async function sendFile(stagedFile, replySnapshot, vis) {
      vis = (vis === "self" || vis === "view") ? vis : "all";
      const id = hex(crypto.getRandomValues(new Uint8Array(8)));
      const ui = renderUploadRow(stagedFile.name, id, vis);
      const controller = new AbortController();
      uploads.set(id, controller);
      ui.cancel.onclick = () => controller.abort();
      let retrying = false;
      ui.retry.onclick = async () => {
        if (retrying) return;
        retrying = true;
        ui.retry.disabled = ui.cancel.disabled = true;
        ui.row.remove(); uploads.delete(id);
        const ok = await sendFile(stagedFile, replySnapshot, vis);
        if (ok) removeFromStaged(stagedFile);
      };
      try {
        if (stagedFile.size > MAX_FILE_SIZE) throw new Error("File too large (max 32 MB).");
        if (!stagedFile.file || stagedFile.size <= 0) throw new Error("Empty or missing file.");

        try {
          const probe = new Uint8Array(await stagedFile.file.slice(0, 1).arrayBuffer());
          if (probe.length === 0 && stagedFile.size > 0) throw new Error("unreadable");
        } catch {
          throw new Error(`${stagedFile.name}: file no longer readable — remove it from the list and re-pick.`);
        }

        if (!stagedFile._fid || stagedFile._epoch !== cur) {
          stagedFile._fid      = hex(crypto.getRandomValues(new Uint8Array(16)));
          stagedFile._epoch    = cur;
          stagedFile._selfKey  = null;
        }
        const fid   = stagedFile._fid;
        const total = Math.max(1, Math.ceil(stagedFile.size / CH));
        const f     = { id: fid, chunks: total, e: cur, vis };

        let fileKey;
        if (vis === "self") {
          if (stagedFile._selfKey) {
            fileKey = stagedFile._selfKey;
          } else {
            const kp = await crypto.subtle.generateKey(
              { name: "AES-GCM", length: 256 }, true, ["encrypt","decrypt"]);
            fileKey = kp;
            const raw = new Uint8Array(await crypto.subtle.exportKey("raw", kp));
            await saveSelfKey(fid, raw);
            stagedFile._selfKey = fileKey;
          }
        } else {
          fileKey = s.keys[cur];
          if (!fileKey) throw new Error("Waiting for the new group key…");
        }

        let have = new Set();
        try {
          const st = await api(`/api/file/status?fid=${fid}`, null, s.token);
          have = new Set(st.have || []);
        } catch {
          try {
            await new Promise(r => setTimeout(r, 400));
            const st = await api(`/api/file/status?fid=${fid}`, null, s.token);
            have = new Set(st.have || []);
          } catch {}
        }
        for (let i = 0; i < total; i++) {
          if (have.has(i)) {
            const p = Math.round((i + 1) / total * 100);
            ui.prog.value = p; ui.pct.textContent = p + "%"; continue;
          }
          if (i > 0) await new Promise(r => setTimeout(r, 50));

          const start = i * CH;
          const end   = Math.min(start + CH, stagedFile.size);

          let sliceData;
          try {
            sliceData = new Uint8Array(await stagedFile.file.slice(start, end).arrayBuffer());
          } catch (e) {
            throw new Error(`${stagedFile.name}: failed reading chunk ${i+1}/${total} — ${e.message || "file unreadable"}`);
          }
          if (sliceData.length !== end - start)
            throw new Error(`${stagedFile.name}: short read on chunk ${i+1}/${total}`);

          const iv = crypto.getRandomValues(new Uint8Array(12));
          const ct = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv, additionalData: aad(f, i) }, fileKey, sliceData);
          const body = new Uint8Array(12 + ct.byteLength);
          body.set(iv); body.set(new Uint8Array(ct), 12);
          const chunkHash = await sha256hex(body);
          const qs = `fid=${fid}&idx=${i}&total=${total}&vis=${vis}&h=${chunkHash}`
                   + (i === 0 ? `&expect=${stagedFile.size}` : "");
          let ok = false, lastErr = null;
          for (let attempt = 0; attempt < 4 && !ok; attempt++) {
            try {
              const r = await fetchWithTimeout(`/api/file/upload?${qs}`,
                { method: "POST", headers: { "X-Token": s.token }, body },
                UPLOAD_TIMEOUT, controller.signal);
              if (r.status === 409) {
                const j = await r.json().catch(() => ({}));
                if (j.error === "visibility changed, restart upload") {
                  stagedFile._fid = null;
                  stagedFile._epoch = null;
                  stagedFile._selfKey = null;
                  throw new Error("Sharing options changed — please retry to re-upload.");
                }
                if (j.error === "chunk already finalized") {
                  console.warn(`[upload] chunk ${i+1}/${total} already finalized — skipping`);
                  ok = true; break;
                }
                ok = true; break;
              }
              if (r.ok) { ok = true; break; }
              if (r.status === 507) throw new Error(friendlyUploadError("quota"));
              if (r.status === 429 || r.status >= 500) {
                await new Promise(res => setTimeout(res, 500 * (1 << attempt)));
                continue;
              }
              const j = await r.json().catch(() => ({}));
              throw new Error(friendlyUploadError(j.error || "upload failed"));
            } catch (e) {
              if (e.name === "AbortError") throw e;
              if (e.message?.includes("Sharing options") ||
                  e.message?.includes("already finalized")) throw e;
              lastErr = e;
              if (attempt === 3) throw e;
              await new Promise(res => setTimeout(res, 500 * (1 << attempt)));
            }
          }
          if (!ok) throw lastErr || new Error("Upload failed");
          const p = Math.round((i + 1) / total * 100);
          ui.prog.value = p; ui.pct.textContent = p + "%";
        }

        const meta = { id: fid, chunks: total, e: f.e, size: stagedFile.size,
                       name: cleanName(stagedFile.name),
                       type: (stagedFile.type || "").slice(0, 60), vis };
        if (stagedFile.voice) {
          meta.voice = true;
          meta.dur   = Math.max(1, Math.min(600, Math.round(stagedFile.dur || 0)));
        }
        const msg = { n: s.nick, f: meta };
        if (replySnapshot) msg.r = replySnapshot;
        await postMsg(msg, { noReply: true });

        stagedFile._fid = null;
        stagedFile._epoch = null;
        stagedFile._selfKey = null;

        ui.pct.textContent = "done"; ui.cancel.hidden = true;
        setTimeout(() => {
          ui.row.remove(); uploads.delete(id);
          if (!uploadsEl.children.length) uploadsEl.hidden = true;
        }, 1500);
        poll();
        return true;
      } catch (e) {
        if (e.name === "AbortError") {
          ui.pct.textContent = "cancelled";
        } else {
          ui.pct.textContent = "failed";
          setStatus(friendlyUploadError(e.message));
        }
        ui.cancel.hidden = true;
        ui.retry.hidden = false;
        return false;
      }
    }

    $("role").textContent = (s.role === "admin" ? "👑 " : "") + s.nick;
    updateGroupName();
    const perr = $("perr"), say = t => { perr.textContent = t; perr.hidden = !t; };
    const btn = (label, cls, fn) => {
      const b = document.createElement("button"); b.textContent = label;
      b.className = cls + " small"; b.onclick = fn; return b;
    };
    const rowEl = (text, ...btns) => {
      const r = document.createElement("div"); r.className = "prow";
      const t = document.createElement("span"); t.textContent = text;
      r.append(t, ...btns); return r;
    };
    const confirmDestructive = (title, body) => window.confirm(`⚠️ ${title}\n\n${body}\n\nAre you sure?`);
    const adm = async (path, body) => {
      say("");
      try { await api(path, body, s.token); await loadPanel(); }
      catch (e) { say(e.message); }
    };

    async function loadPanel() {
      try {
        const r = await api("/api/admin/members", null, s.token);
        if (r.file_policy) setFilePolicy(r.file_policy);
        if (r.name !== undefined && r.name !== s.groupName) {
          s.groupName = r.name || ""; save(); updateGroupName();
        }
        const ml = $("members"), bl = $("blocked"); ml.textContent = ""; bl.textContent = "";
        for (const m of r.members) {
          const dot = m.online ? "🟢 " : "⚪ ";
          const cr = m.role === "admin" ? "👑 " : "";
          const who = dot + cr + (nicks[m.id] || "unknown") + " · " + m.fp + " · " + m.role
                    + (m.id === me ? " (you)" : "") + " · " + m.msgs + " msgs";
          ml.append(m.role === "admin" ? rowEl(who) : rowEl(who,
            btn("Kick", "alt", () => confirmDestructive("Remove member", "They can rejoin with the keys unless blocked.")
              && adm("/api/admin/kick", { member_id: m.id, wipe: $("wipe").checked })),
            btn("Block", "danger", () => confirmDestructive("Block this device", "They will not be able to rejoin.")
              && adm("/api/admin/block", { member_id: m.id, wipe: $("wipe").checked }))));
        }
        if (!r.blocked.length) bl.append(rowEl("No blocked devices."));
        for (const x of r.blocked) bl.append(rowEl(
          x.fp + " · " + new Date(x.ts * 1000).toLocaleDateString(),
          btn("Unblock", "alt", () => adm("/api/admin/unblock", { fp: x.fp }))));
        const ev = await api("/api/admin/events", null, s.token), el = $("events");
        if (el) {
          el.textContent = "";
          if (!ev.events.length) el.append(rowEl("No activity yet."));
          for (const e of ev.events) el.append(rowEl(
            `${e.kind}${e.target_fp ? " · " + e.target_fp.slice(0,8) : ""} · ${new Date(e.ts*1000).toLocaleString()}`));
        }
      } catch (e) { say(e.message); }
    }

    if (s.role === "admin") {
      $("adminbtn").hidden = false;
      $("adminbtn").onclick = () => { $("panel").hidden = false; loadPanel(); };
      $("panelclose").onclick = () => { $("panel").hidden = true; };
      $("purge").onclick = async () => {
        if (!confirmDestructive("Delete all messages and files", "For every member. Cannot be undone.")) return;
        try {
          await api("/api/purge", {}, s.token);
          box.textContent = ""; msgEls.clear(); reactionsMap.clear(); releaseBlobUrls();
        } catch (e) { say(e.message); }
      };
      $("delgroup").onclick = async () => {
        if ($("delconfirm").value !== "DELETE") return say("Type DELETE exactly to confirm.");
        if (!confirmDestructive("Delete the entire group", "Members, messages, files — all permanently gone.")) return;
        try {
          const r = await api("/api/admin/delete-group", { confirm: "DELETE" }, s.token);
          await kvDel("session"); releaseBlobUrls();
          await wipeSelfKeys();
          alert(r.clean ? "Group deleted cleanly." : "Group deleted, but some cleanup issues were logged.");
          location.href = "/";
        } catch (e) { say(e.message); }
      };

      // ----- Quick rename (admin only, no admin key) -----
      {
        const renameBtn   = $("rename-btn");
        const renameInput = $("rename-input");
        const renameErr   = $("rename-err");
        if (renameBtn && renameInput) {
          if (s.groupName) renameInput.value = s.groupName;
          renameBtn.onclick = async () => {
            renameErr.hidden = true;
            const name = renameInput.value.trim();
            if (!name) { renameErr.textContent = "Enter a name."; renameErr.hidden = false; return; }
            if (name.length > 60) { renameErr.textContent = "Max 60 characters."; renameErr.hidden = false; return; }
            renameBtn.disabled = true;
            try {
              const r = await api("/api/admin/rename", { name }, s.token);
              s.groupName = r.name;
              await save();
              updateGroupName();
              setStatus("Group renamed");
            } catch (e) {
              renameErr.textContent = e.message; renameErr.hidden = false;
            } finally { renameBtn.disabled = false; }
          };
        }
      }

      // ----- Change credentials (rotate keys + name + policy) -----
      {
        const apply     = $("cred-apply");
        const genBtn    = $("cred-gen");
        const copyBtn   = $("cred-copy");
        const curGidEl  = $("cred-gid-cur");
        const newGidEl  = $("cred-gid-new");
        const newInvEl  = $("cred-inv-new");
        const newAdmEl  = $("cred-adm-new");
        const nameEl    = $("cred-name");
        const polEl     = $("cred-policy");
        const credErr   = $("cred-err");
        const resultBox = $("cred-result");
        const resultPre = $("cred-result-pre");

        if (s.gid && curGidEl) curGidEl.value = s.gid.join(" ");
        if (nameEl && s.groupName) nameEl.placeholder = s.groupName;
        if (polEl) polEl.value = "";

        if (genBtn) genBtn.onclick = () => {
          const anyFilled = newGidEl.value.trim() || newInvEl.value.trim() || newAdmEl.value.trim();
          if (anyFilled && !confirm("Overwrite the 'new credentials' fields with freshly generated ones?")) return;
          newGidEl.value = gen(8).join(" ");
          newInvEl.value = gen(16).join(" ");
          newAdmEl.value = gen(32).join(" ");
        };

        if (copyBtn) copyBtn.onclick = async () => {
          try {
            await navigator.clipboard.writeText(resultPre.textContent);
            copyBtn.textContent = "✓ Copied";
            setTimeout(() => { copyBtn.textContent = "📋 Copy to clipboard"; }, 2000);
          } catch { copyBtn.textContent = "Copy failed"; }
        };

        if (apply) apply.onclick = async () => {
          credErr.hidden   = true;
          resultBox.hidden = true;
          apply.disabled   = true;
          apply.textContent = "Applying…";
          try {
            const curGid = norm(curGidEl.value);
            const curAdm = norm($("cred-adm-cur").value);
            const newGid = norm(newGidEl.value);
            const newInv = norm(newInvEl.value);
            const newAdm = norm(newAdmEl.value);
            const newName = (nameEl?.value || "").trim();
            const newPolicy = polEl?.value || "";

            const changeGid = newGid.length > 0;
            const changeInv = newInv.length > 0;
            const changeAdm = newAdm.length > 0;
            const changeName = newName.length > 0 && newName !== (s.groupName || "");
            const changePolicy = newPolicy.length > 0 && newPolicy !== filePolicy;

            if (!checkWords(curGid, 8))
              throw new Error("Current Group ID must be exactly 8 words.");
            if (!checkWords(curAdm, 32))
              throw new Error("Current Admin Key must be exactly 32 words.");
            if (!changeGid && !changeInv && !changeAdm && !changeName && !changePolicy)
              throw new Error("Enter at least one change.");
            if (changeGid && !checkWords(newGid, 8))
              throw new Error("New Group ID must be exactly 8 words.");
            if (changeInv && !checkWords(newInv, 16))
              throw new Error("New Invite Key must be exactly 16 words.");
            if (changeAdm && !checkWords(newAdm, 32))
              throw new Error("New Admin Key must be exactly 32 words.");
            if (changeGid && (!changeInv || !changeAdm))
              throw new Error(
                "Changing Group ID requires also providing a new Invite Key " +
                "and Admin Key (their verification hashes depend on the Group ID).");
            if (changeName && (newName.length < 1 || newName.length > 60))
              throw new Error("Group name must be 1–60 characters.");

            if (changeGid || changeInv || changeAdm) {
              const preview =
                (changeGid ? `Group ID:   ${newGid.join(" ")}\n` : "") +
                (changeInv ? `Invite Key: ${newInv.join(" ")}\n` : "") +
                (changeAdm ? `Admin Key:  ${newAdm.join(" ")}\n` : "");
              if (!confirm(
                "⚠ These new credentials will REPLACE the current ones:\n\n" +
                preview +
                "\nCopy them NOW — they cannot be recovered later.\n\n" +
                "Continue?"
              )) return;
            } else if (changeAdm) {
              if (!confirm(
                "⚠ You are changing the ADMIN KEY.\n\n" +
                "The new Admin Key will be the ONLY way to authorise future " +
                "credential changes and grant admin access to new members.\n\n" +
                "Have you saved the new Admin Key somewhere safe?\n\nContinue?"
              )) return;
            }

            const currentAdminV = await derive("verify-admin", curGid, curAdm);
            const finalGid = changeGid ? newGid : curGid;
            const newInvV  = changeInv ? await derive("verify-invite", finalGid, newInv) : null;
            const newAdmV  = changeAdm ? await derive("verify-admin",  finalGid, newAdm) : null;

            const body = {
              current_gid:     curGid,
              current_admin_v: currentAdminV,
            };
            if (changeGid)    body.new_gid    = newGid;
            if (changeInv)    body.new_inv_v  = newInvV;
            if (changeAdm)    body.new_adm_v  = newAdmV;
            if (changeName)   body.new_name   = newName;
            if (changePolicy) body.new_policy = newPolicy;

            const resp = await api("/api/admin/change-credentials", body, s.token);

            ["cred-gid-cur","cred-adm-cur","cred-gid-new","cred-inv-new","cred-adm-new"]
              .forEach(id => { const el = $(id); if (el) el.value = ""; });
            if (nameEl) nameEl.value = "";
            if (polEl)  polEl.value  = "";

            if (resp.name !== undefined)        { s.groupName = resp.name; }
            if (resp.file_policy !== undefined) { setFilePolicy(resp.file_policy); }
            if (changeGid) s.gid = newGid;
            await save();
            updateGroupName();

            let txt = "";
            if (changeGid)    txt += `GROUP ID (8)\n${newGid.join(" ")}\n\n`;
            if (changeInv)    txt += `INVITE KEY (16)\n${newInv.join(" ")}\n\n`;
            if (changeAdm)    txt += `ADMIN KEY (32, keep private)\n${newAdm.join(" ")}\n\n`;
            if (changeName)   txt += `GROUP NAME\n${newName}\n\n`;
            if (changePolicy) txt += `DOWNLOAD POLICY\n${newPolicy}\n\n`;
            resultPre.textContent = txt.trim() || "(change applied — no visible values to display)";
            resultBox.hidden = false;

            if (resp.rotating) {
              const prevEpoch = cur;
              setStatus("rotating group key…");
              await refresh().catch(() => {});
              if (cur > prevEpoch) setStatus(`credentials updated (epoch ${cur})`);
              else {
                setStatus("⚠️ rotation incomplete — retrying");
                setBanner("⚠️ Rotation did not complete. Click Retry to try again.",
                  () => { refresh().then(() => poll()).catch(() => {}); });
              }
            } else {
              setStatus("settings updated");
            }
          } catch (e) {
            credErr.textContent = e.message;
            credErr.hidden = false;
          } finally {
            apply.disabled = false;
            apply.textContent = "Apply changes";
          }
        };
      }
    }

    let staged = [];
    const stageVis = () => {
      const v = $("stage-vis")?.value;
      return (v === "self" || v === "view") ? v : "all";
    };
    const totalStagedBytes = () => staged.reduce((n, f) => n + f.size, 0);
    function removeFromStaged(stagedFile) {
      const idx = staged.indexOf(stagedFile);
      if (idx >= 0) { staged.splice(idx, 1); renderStage(); }
    }

    async function addFilesToStaging(files) {
      const errs = [];
      const list = Array.from(files);
      if (!list.length) return errs;

      for (const f of list) {
        if (staged.length >= MAX_STAGED_FILES) { errs.push(`Max ${MAX_STAGED_FILES} files at a time`); break; }
        if (f.size === 0) { errs.push(`${f.name}: empty file`); continue; }
        if (f.size > MAX_FILE_SIZE) { errs.push(`${f.name}: over 32 MB, skipped`); continue; }
        if (totalStagedBytes() + f.size > MAX_STAGED_BYTES) {
          errs.push(`${f.name}: would exceed staging cap of ${fmt(MAX_STAGED_BYTES)}`);
          continue;
        }

        setStatus(`Checking ${f.name}…`);
        await new Promise(r => setTimeout(r, 0));

        try {
          const probe = new Uint8Array(await f.slice(0, 1).arrayBuffer());
          if (probe.length === 0) throw new Error("empty probe");
        } catch (e) {
          errs.push(`${f.name}: unreadable (${e.message || e.name}) — try picking again`);
          continue;
        }

        staged.push({ name: f.name, size: f.size, type: f.type || "", file: f });
        renderStage();
      }
      return errs;
    }

    const renderStage = () => {
      const l = $("stagelist"); l.textContent = ""; $("stage").hidden = !staged.length;
      const vis = stageVis();
      const icon = vis === "self" ? "🔒 " : vis === "view" ? "👁 " : "";
      staged.forEach((f) => {
        const r = document.createElement("div"); r.className = "prow";
        if (["image/png","image/jpeg","image/gif","image/webp"].includes(f.type) && f.file) {
          const im = document.createElement("img");
          im.className = "thumb";
          const url = URL.createObjectURL(f.file);
          im.src = url;
          im.onload = () => URL.revokeObjectURL(url);
          im.onerror = () => URL.revokeObjectURL(url);
          r.append(im);
        }
        const t = document.createElement("span");
        t.textContent = icon + fileIcon(f.type, f.name) + " " + f.name + " (" + fmt(f.size) + ")";
        r.append(t, btn("✕", "alt", () => removeFromStaged(f)));
        l.append(r);
      });
      $("stagesend").textContent = icon + "Send " + staged.length + (staged.length === 1 ? " file" : " files");
    };
    $("stage-vis")?.addEventListener("change", renderStage);

    const attachBtn = $("attach"), attachMenu = $("attach-menu"), fileInput = $("file");
    const closeAttachMenu = () => {
      attachMenu.hidden = true; attachBtn.setAttribute("aria-expanded", "false");
    };
    attachBtn.onclick = (e) => {
      e.preventDefault();
      attachMenu.hidden = !attachMenu.hidden;
      attachBtn.setAttribute("aria-expanded", attachMenu.hidden ? "false" : "true");
    };
    attachMenu.addEventListener("click", (e) => {
      const b = e.target.closest("button[data-accept]"); if (!b) return;
      fileInput.value = "";
      if (b.dataset.accept) fileInput.setAttribute("accept", b.dataset.accept);
      else fileInput.removeAttribute("accept");
      if (b.dataset.capture) fileInput.setAttribute("capture", b.dataset.capture);
      else fileInput.removeAttribute("capture");
      closeAttachMenu(); fileInput.click();
    });
    document.addEventListener("click", (e) => {
      if (!attachMenu.hidden && !attachMenu.contains(e.target) && !attachBtn.contains(e.target)) closeAttachMenu();
    });

    fileInput.onchange = async () => {
      const files = Array.from(fileInput.files);
      fileInput.value = "";
      const errs = await addFilesToStaging(files);
      setStatus(errs.length ? errs.join("; ") : (wsAlive ? "connected (live)" : "connected"));
    };

    const dropOverlay = document.createElement("div");
    dropOverlay.className = "drop-overlay";
    dropOverlay.textContent = "Drop files to send (max 32 MB each)";
    document.body.append(dropOverlay);
    let dragDepth = 0;
    box.addEventListener("dragenter", e => {
      if (!e.dataTransfer?.types?.includes("Files")) return;
      e.preventDefault(); dragDepth++; dropOverlay.classList.add("show");
    });
    box.addEventListener("dragover", e => { if (e.dataTransfer?.types?.includes("Files")) e.preventDefault(); });
    box.addEventListener("dragleave", () => {
      dragDepth = Math.max(0, dragDepth - 1);
      if (dragDepth === 0) dropOverlay.classList.remove("show");
    });
    box.addEventListener("drop", async e => {
      if (!e.dataTransfer?.files?.length) return;
      e.preventDefault(); dragDepth = 0; dropOverlay.classList.remove("show");
      const errs = await addFilesToStaging(e.dataTransfer.files);
      setStatus(errs.length ? errs.join("; ") : (wsAlive ? "connected (live)" : "connected"));
    });

    $("stagecancel").onclick = () => { staged = []; renderStage(); };
    $("stagesend").onclick = async () => {
      if ($("stagesend").disabled) return;
      $("stagesend").disabled = $("stagecancel").disabled = true;
      const vis = stageVis();
      const replySnap = replyTo; if (replySnap) { replyTo = null; renderReplyPreview(); }
      try {
        while (staged.length) {
          const ok = await sendFile(staged[0], replySnap, vis);
          if (!ok) break;
          staged.shift(); renderStage();
        }
      } catch (x) {
        setStatus(friendlyUploadError(x.message));
      }
      $("stagesend").disabled = $("stagecancel").disabled = false;
    };

    let rec = null;
    let recLevels = [];

    function pickVoiceMime() {
      const cands = [
        "audio/webm;codecs=opus", "audio/webm",
        "audio/mp4;codecs=mp4a.40.2", "audio/mp4",
        "audio/ogg;codecs=opus", "audio/ogg",
      ];
      for (const m of cands) {
        try { if (MediaRecorder.isTypeSupported(m)) return m; } catch {}
      }
      return "";
    }

    function showRecBar() {
      const rb = $("recbar"), sf = $("send");
      if (rb) rb.hidden = false;
      if (sf) sf.hidden = true;
      requestAnimationFrame(() => {
        const c = $("recwave");
        if (!c) return;
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        const r = c.getBoundingClientRect();
        if (r.width > 0) {
          c.width  = Math.round(r.width * dpr);
          c.height = Math.round(36    * dpr);
        }
      });
    }
    function hideRecBar() {
      const rb = $("recbar"), sf = $("send");
      if (rb) rb.hidden = true;
      if (sf) sf.hidden = false;
    }

    function tickRec() {
      if (!rec) return;
      const s = Math.floor((Date.now() - rec.start) / 1000);
      const t = $("rectimer");
      if (t) t.textContent = Math.floor(s/60) + ":" + String(s%60).padStart(2, "0");
      if (s >= MAX_VOICE_SECONDS) { stopRecording(false); return; }
      rec.timer = setTimeout(tickRec, 250);
    }

    function drawRec() {
      if (!rec || !rec.analyser) return;
      const c = $("recwave");
      if (!c) return;
      const ctx = c.getContext("2d");
      const W = c.width, H = c.height;
      const buf = new Uint8Array(rec.analyser.fftSize);
      rec.analyser.getByteTimeDomainData(buf);
      let sum = 0;
      for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; sum += v * v; }
      const rms = Math.sqrt(sum / buf.length);
      recLevels.push(rms);
      const barW = Math.max(3, Math.round(H / 18));
      const maxBars = Math.max(1, Math.floor(W / barW));
      while (recLevels.length > maxBars) recLevels.shift();
      ctx.clearRect(0, 0, W, H);
      const acc = getComputedStyle(document.documentElement)
                    .getPropertyValue("--acc").trim() || "#7fe0a8";
      ctx.fillStyle = acc;
      const offset = W - recLevels.length * barW;
      for (let i = 0; i < recLevels.length; i++) {
        const h = Math.max(2, Math.min(H, recLevels[i] * H * 3));
        ctx.fillRect(offset + i * barW, (H - h) / 2, barW - 1, h);
      }
      rec.raf = requestAnimationFrame(drawRec);
    }

    function cleanupRec() {
      const r = rec; rec = null;
      if (!r) return;
      clearTimeout(r.timer);
      if (r.raf) cancelAnimationFrame(r.raf);
      try { r.stream.getTracks().forEach(t => t.stop()); } catch {}
      try { if (r.ctx) r.ctx.close(); } catch {}
      recLevels = [];
    }

    async function startRecording() {
      if (rec) return;
      closeAttachMenu();
      for (const a of voiceAudios) {
        try { if (!a.paused) a.pause(); } catch {}
      }
      if (!navigator.mediaDevices?.getUserMedia) {
        return setStatus("Microphone is not available in this browser");
      }
      if (typeof MediaRecorder === "undefined") {
        return setStatus("Recording not supported in this browser");
      }
      let stream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true }
        });
      } catch { return setStatus("Microphone permission denied"); }

      const mime = pickVoiceMime();
      if (!mime) {
        stream.getTracks().forEach(t => t.stop());
        return setStatus("No supported audio recording format");
      }

      let mr;
      try {
        mr = new MediaRecorder(stream, { mimeType: mime, audioBitsPerSecond: 32000 });
      } catch (e) {
        stream.getTracks().forEach(t => t.stop());
        return setStatus("Recorder init failed: " + e.message);
      }

      const chunks = [];
      mr.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };

      rec = { mr, stream, chunks, mime, start: Date.now(),
              cancelled: false, ctx: null, analyser: null, raf: 0, timer: 0 };
      mr.onstop = () => onRecordStop();

      try { mr.start(250); }
      catch { cleanupRec(); return setStatus("Could not start recording"); }

      try {
        const AC  = window.AudioContext || window.webkitAudioContext;
        const ctx = new AC();
        const src = ctx.createMediaStreamSource(stream);
        const an  = ctx.createAnalyser();
        an.fftSize = 1024; an.smoothingTimeConstant = 0.5;
        src.connect(an);
        rec.ctx = ctx; rec.analyser = an;
      } catch {}

      showRecBar(); tickRec(); drawRec();
    }

    function stopRecording(cancel) {
      if (!rec) return;
      rec.cancelled = !!cancel;
      try { rec.mr.stop(); }
      catch { cleanupRec(); hideRecBar(); }
    }

    async function onRecordStop() {
      const r = rec;
      if (!r) return;
      const cancelled = r.cancelled;
      const dur = Math.max(1, Math.round((Date.now() - r.start) / 1000));
      const { chunks, mime, start } = r;
      cleanupRec();
      hideRecBar();
      if (cancelled) return;

      const blob = new Blob(chunks, { type: mime });
      if (!blob.size) return setStatus("Nothing recorded");
      const ext = mime.includes("webm") ? "webm"
                : mime.includes("mp4")  ? "m4a" : "ogg";
      const file = new File([blob], `voice-${start}.${ext}`, { type: mime });
      const stagedVoice = { name: file.name, size: file.size, type: file.type,
                            file, voice: true, dur };

      const replySnap = replyTo; if (replySnap) { replyTo = null; renderReplyPreview(); }
      const ok = await sendFile(stagedVoice, replySnap, "all");
      if (!ok) setStatus("Voice message failed to send — tap ⟳ in the uploads panel to retry.");
    }

    {
      const mic = $("mic");
      if (mic) mic.onclick = () => { if (rec) stopRecording(false); else startRecording(); };
      const rc = $("rec-cancel");
      if (rc) rc.onclick = () => stopRecording(true);
      const rs = $("rec-send");
      if (rs) rs.onclick = () => stopRecording(false);
      window.addEventListener("beforeunload", () => { if (rec) cleanupRec(); });
    }

    let sending = false;
    $("send").onsubmit = async e => {
      e.preventDefault();
      const t = $("text").value.trim();
      if (!t || sending) return;
      sending = true;
      const sendBtn = $("sendbtn");
      const cid = genCid();
      const payload = { n: s.nick, t, cid };

      const who = (me && nicks[me]) || s.nick;
      const temp = addText("me", who, t, Math.floor(Date.now() / 1000), null, null, me || null);
      temp.classList.add("pending");
      $("text").value = "";

      try {
        setStatus("sending…"); sendBtn.disabled = true;
        const resp = await postMsg(payload);
        if (resp && resp.id) {
          seen.add(resp.id);
          temp.dataset.id = resp.id;
          temp.classList.remove("pending");
          msgEls.set(resp.id, temp);
          addActions(temp, resp.id, who, t);
          updateReactionsUI(resp.id);
        }
        setStatus("sent");
        setTimeout(() => setStatus(wsAlive ? "connected (live)" : "connected"), 800);
        poll();
      } catch (x) {
        const msg = String(x.message || "");
        const waitingForKey = !x.status && msg.includes("Waiting for the new group key");
        if (x.status === 409 || waitingForKey) {
          // Rotation in progress — queue and retry once the epoch changes.
          setStatus("key rotating…");
          enqueueMsg(payload, temp, who, t);
          setBanner("Message will send once the group key rotation completes.", null);
        } else if (!x.status || x.status >= 500) {
          enqueueMsg(payload, temp, who, t);
          setStatus("queued (offline)");
          setBanner("Message queued — will send when you reconnect", null);
        } else {
          temp.remove();
          setStatus("failed: " + x.message);
        }
      } finally {
        sending = false; sendBtn.disabled = false;
      }
    };

    $("text").addEventListener("input", () => {
      const now = Date.now(); if (now - lastTypingAt[0] < 2000) return;
      lastTypingAt[0] = now;
      if (ws && wsAlive && ws.readyState === WebSocket.OPEN) {
        try { ws.send(JSON.stringify({ type: "typing" })); } catch {}
      }
    });

    async function pollOnce() {
      try {
        const r = await api("/api/messages?after=" + after, null, s.token);
        me = r.me;
        if (!loaded) {
          loaded = true;
          const l = $("loading"); if (l) l.hidden = true;
          maybeShowPolicyBanner();
        }
        if (r.file_policy) setFilePolicy(r.file_policy);
        if (r.name !== undefined) { s.groupName = r.name || ""; save(); updateGroupName(); }
        if (Array.isArray(r.online)) { onlineSet = new Set(r.online); updatePresence(); }
        if (r.epoch !== cur || r.rot || !members[me]) await refresh();

        for (const m of r.messages) {
          if (!m || typeof m !== "object") continue;
          if (!Number.isInteger(m.id) || m.id <= 0) continue;
          if (typeof m.m !== "string" || m.m.length === 0 || m.m.length > 64) continue;
          if (typeof m.iv !== "string" || typeof m.ct !== "string") continue;
          if (typeof m.ts !== "number" || !Number.isFinite(m.ts)) continue;

          const ivParts = m.iv.split(":");
          if (ivParts.length !== 2) continue;
          const [e, ivb] = ivParts;
          const ep = parseInt(e, 10);
          if (!Number.isInteger(ep) || ep < 0 || ep > 1_000_000) continue;
          const key = s.keys[ep];
          if (!key) {
            if (ep >= cur) break;
            after = m.id;
            if (!seen.has(m.id)) {
              seen.add(m.id);
              const ph = addMsgBubble("bad", "🔒 older message", m.ts, m.id, null, null);
              const p = document.createElement("p");
              p.style.color = "var(--dim)";
              p.style.fontStyle = "italic";
              p.textContent = "Sent before the group's credentials were rotated — no longer readable on this device.";
              ph.append(p);
            }
            continue;
          }

          after = m.id;
          if (seen.has(m.id)) continue;
          seen.add(m.id);
          if (seen.size > 5000) {
            const it = seen.values();
            for (let i = 0; i < 2500; i++) seen.delete(it.next().value);
          }

          const ctParts = m.ct.split(".");
          if (ctParts.length !== 2) { addUnverified(m.ts, m.id); continue; }
          const [ctb, sig] = ctParts;
          if (!ctb || !sig) { addUnverified(m.ts, m.id); continue; }

          let o;
          try {
            const pt = await crypto.subtle.decrypt(
              { name: "AES-GCM", iv: unb64(ivb), additionalData: enc.encode("v2:" + ep) },
              key, unb64(ctb));
            o = JSON.parse(dec.decode(pt));
          } catch {
            addText("bad", "unknown", "[could not decrypt]", m.ts, null, null, null);
            continue;
          }
          if (!o || typeof o !== "object") {
            addText("bad", "unknown", "[malformed message]", m.ts, null, null, null);
            continue;
          }

          const sigInput = m.cid
            ? enc.encode(`${ep}:${ivb}:${ctb}:${m.cid}`)
            : enc.encode(`${ep}:${ivb}:${ctb}`);
          const ok = await verify(m.m, sigInput, sig);
          if (!ok) { addUnverified(m.ts, m.id); continue; }

          if (typeof o.n !== "string" || o.n.length === 0 || o.n.length > 24) {
            addText("bad", "unknown", "[malformed message]", m.ts, null, null, null);
            continue;
          }
          const claimed = o.n;
          if (!nickPinned.has(m.m)) {
            nicks[m.m] = claimed; nickPinned.add(m.m); saveNicks();
          } else if (nicks[m.m] !== claimed) {
            const old = nicks[m.m]; nicks[m.m] = claimed; saveNicks();
            setBanner(`⚠️ ${old} changed name to ${claimed} — verify this is the same person`, null);
          }
          clearTyping(m.m);

          if (o.react !== undefined) {
            if (o.react && typeof o.react === "object") {
              const targetId = Number(o.react.m);
              const emoji = o.react.e;
              if (Number.isInteger(targetId) && targetId > 0 &&
                  typeof emoji === "string" && emoji.length > 0 && emoji.length <= 8) {
                applyReaction(targetId, emoji, m.m);
              }
            }
            continue;
          }

          const cls = m.m === me ? "me" : "";
          const who = crown(m.m) + (nicks[m.m] || "unknown");

          let replyData = null;
          if (o.r !== undefined) {
            if (o.r && typeof o.r === "object" &&
                typeof o.r.who === "string" && o.r.who.length > 0 && o.r.who.length <= 100 &&
                typeof o.r.p === "string" && o.r.p.length <= 200 &&
                Number.isInteger(o.r.id) && o.r.id > 0) {
              replyData = { id: o.r.id, who: o.r.who, p: o.r.p };
            }
          }

          if (o.f !== undefined) {
            if (!validFile(o.f)) {
              addText("bad", "unknown", "[malformed file]", m.ts, null, null, null);
              continue;
            }
            const vis = (o.f.vis === "self" || o.f.vis === "view") ? o.f.vis : "all";
            addFile(cls, who, {
              id: o.f.id, chunks: o.f.chunks, e: o.f.e, size: o.f.size,
              name: cleanName(o.f.name), type: String(o.f.type || ""), vis,
              voice: o.f.voice === true,
              dur: typeof o.f.dur === "number" ? o.f.dur : undefined
            }, m.ts, m.id, replyData, m.m);
            continue;
          }

          if (typeof o.t !== "string" || o.t.length === 0 || o.t.length > 4000) {
            addText("bad", "unknown", "[malformed message]", m.ts, null, null, null);
            continue;
          }
          addText(cls, who, o.t, m.ts, m.id, replyData, m.m);
        }

        setStatus(s.keys[r.epoch]
          ? (wsAlive ? "connected (live)" : "connected")
          : "waiting for group key…");

        if (msgQueue.length) flushQueue();
      } catch (x) {
        if (x.status === 401) {
          const fresh = await kvGet("session").catch(() => null);
          if (fresh && fresh.token && fresh.token !== s.token &&
              (fresh.tokenRotatedAt || 0) > (s.tokenRotatedAt || 0)) {
            s.token = fresh.token; s.tokenRotatedAt = fresh.tokenRotatedAt;
            await save(); setStatus("session refreshed"); return poll();
          }
          const now = Date.now();
          if (!s._kickAt || now - s._kickAt > 60_000) {
            s._kickAt = now; await save();
            setBanner("Session ended. Rejoin with your keys to continue.", () => {
              location.href = "/join-group.html";
            });
          }
          return;
        }
        if (x.status === 429) {
          setDot("poll"); setStatus("throttled, backing off…");
          await new Promise(r => setTimeout(r, 5000));
          return;
        }
        setDot("off");
        setStatus(x.name === "TimeoutError" || x.name === "AbortError"
          ? "connection timed out, retrying…"
          : "offline, retrying…");
      }
    }
    let busy = false, again = false;
    async function poll() {
      if (busy) { again = true; return; }
      busy = true;
      try { await pollOnce(); } finally { busy = false; }
      if (again) { again = false; poll(); }
    }

    function openWS() {
      let url;
      try {
        url = (location.protocol === "https:" ? "wss:" : "ws:") + "//" + location.host + "/api/ws";
        ws = new WebSocket(url, [s.token]);
      } catch { return scheduleWS(); }
      const handshakeTimer = setTimeout(() => {
        if (ws && ws.readyState === WebSocket.CONNECTING) {
          try { ws.close(); } catch {}
        }
      }, 10000);
      ws.onopen = () => {
        clearTimeout(handshakeTimer);
        wsAlive = true; wsRetry = 0; lastPong = Date.now();
        setDot("live"); setStatus("connected (live)"); setBanner("");
        clearInterval(wsHeartbeat);
        wsHeartbeat = setInterval(() => {
          if (!ws || ws.readyState !== WebSocket.OPEN) return;
          if (Date.now() - lastPong > 45000) { try { ws.close(); } catch {} return; }
          try { ws.send(JSON.stringify({ type: "ping" })); } catch {}
        }, 20000);
      };
      ws.onmessage = ev => {
        try {
          const m = JSON.parse(ev.data);
          if (m.type === "pong") { lastPong = Date.now(); return; }
          if (m.type === "purge") {
            box.textContent = ""; msgEls.clear(); reactionsMap.clear();
            after = 0; seen.clear(); releaseBlobUrls(); poll();
          }
          else if (m.type === "new" || m.type === "refresh") poll();
          else if (m.type === "presence") { onlineSet = new Set(m.online || []); updatePresence(); }
          else if (m.type === "typing") showTyping(m.from);
        } catch {}
      };
      ws.onclose = () => {
        clearTimeout(handshakeTimer);
        wsAlive = false; setDot("poll"); clearInterval(wsHeartbeat); wsHeartbeat = null;
        if (wsRetry === 2) { poll(); setBanner("Live updates lost, retrying with polling…", null); }
        scheduleWS();
      };
      ws.onerror = (e) => {
        console.warn("[ws] connection error — will retry with backoff", e);
      };
    }
    function scheduleWS() {
      if (wsAlive) return;
      const d = Math.min(30000, 1000 * Math.pow(2, wsRetry++));
      setTimeout(openWS, d);
    }

    async function rotateTokenIfStale() {
      const now = Date.now();
      if (s.tokenRotatedAt && now - s.tokenRotatedAt < 6 * 3600_000) return;
      const doRotate = async () => {
        const fresh = await kvGet("session");
        if (fresh && fresh.tokenRotatedAt && Date.now() - fresh.tokenRotatedAt < 6 * 3600_000) {
          s.token = fresh.token; s.tokenRotatedAt = fresh.tokenRotatedAt; return;
        }
        try {
          const r = await api("/api/auth/rotate-token", {}, s.token);
          s.token = r.token; s.tokenRotatedAt = Date.now(); await save();
          if (bc) bc.postMessage({ type: "token", token: r.token, at: s.tokenRotatedAt });
          if (ws) { try { ws.close(); } catch {} }
        } catch (e) { console.warn("token rotate failed:", e.message); }
      };
      if (navigator.locks?.request) {
        try { await navigator.locks.request("token-rotate", doRotate); return; } catch {}
      }
      await doRotate();
    }
    await rotateTokenIfStale();
    setInterval(rotateTokenIfStale, 6 * 3600_000);

    openWS(); poll(); updatePresence(); setDot("poll");
    setInterval(() => { if (!wsAlive) poll(); }, 4000);
    window.addEventListener("online", () => {
      wsRetry = 0; if (!wsAlive) openWS(); poll(); setBanner("");
      flushQueue();
    });
    window.addEventListener("offline", () => {
      setDot("off"); setStatus("offline");
      setBanner("You are offline. Messages will send when you reconnect.", null);
    });
    document.addEventListener("keydown", e => {
      if (e.key === "Escape") {
        if (!$("panel").hidden) $("panel").hidden = true;
        const p = document.querySelector(".emoji-picker"); if (p) p.remove();
        closeAttachMenu();
      }
    });

    async function wipeSelfKeys() {
      try {
        const d = await idb();
        const keys = await new Promise((res, rej) => {
          const q = d.transaction("kv").objectStore("kv").getAllKeys();
          q.onsuccess = () => res(q.result || []);
          q.onerror = () => rej(q.error);
        });
        const t = d.transaction("kv", "readwrite");
        const st = t.objectStore("kv");
        for (const k of keys) if (typeof k === "string" && k.startsWith("selfkey:")) st.delete(k);
        await new Promise(r => { t.oncomplete = r; });
      } catch {}
    }

    $("leave").onclick = async () => {
      if (!confirm("Leave this group on this device? You can rejoin with your keys.")) return;
      if (rec) cleanupRec();
      releaseBlobUrls();
      await kvDel(qKey);
      await kvDel(QKEY_IDB);
      await wipeSelfKeys();
      await kvDel("session");
      location.href = "/";
    };
  }
};
pages[document.body.dataset.page]?.();
