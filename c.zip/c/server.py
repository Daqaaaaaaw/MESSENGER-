#!/usr/bin/env python3
"""Anonymous E2EE group messenger — production build (hardened).
Env: PORT, DATA_DIR, RETENTION_DAYS, DISK_WARN_PCT, STALE_FILE_SECONDS,
     MAINT_INTERVAL, FILE_DOWNLOAD_POLICY, PEPPER_PATH, REQUEST_TIMEOUT,
     UPLOAD_TIMEOUT, WS_IDLE_TIMEOUT, MAX_WS_PER_GROUP, MAX_WS_TOTAL,
     MAX_WS_PER_IP, MAX_CONCURRENT_UPLOADS, REQUIRE_CHUNK_HASH,
     ALLOW_UNSIGNED_DH, BIND_HOST, TRUST_PROXY, UPLOAD_DEADLINE_SECONDS

CLI:
    python3 server.py                    # run the server
    python3 server.py --backup <dir>     # verified backup (db + pepper + hmac_key)
"""
import base64, hashlib, hmac, json, os, re, secrets, shutil, signal, sqlite3, ssl
import struct, sys, threading, time, traceback, uuid
from contextlib import contextmanager
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

os.umask(0o077)

ROOT = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(ROOT, "static")
DATA = os.environ.get("DATA_DIR") or os.path.join(ROOT, "data")
os.makedirs(DATA, mode=0o700, exist_ok=True)
ITER = 100_000
MAX_BODY = 128 * 1024
FILES = os.path.join(DATA, "files")
CHUNK_MAX = 1024 * 1024 + 64
MAX_CHUNKS = 32
GROUP_QUOTA = 256 * 1024 * 1024
STALE_FILE_SECONDS      = int(os.environ.get("STALE_FILE_SECONDS", "600"))
UPLOAD_DEADLINE_SECONDS = int(os.environ.get("UPLOAD_DEADLINE_SECONDS", "3600"))
RETENTION_DAYS     = int(os.environ.get("RETENTION_DAYS", "0"))
DISK_WARN_PCT      = int(os.environ.get("DISK_WARN_PCT", "85"))
MAINT_INTERVAL     = int(os.environ.get("MAINT_INTERVAL", "3600"))
REQUEST_TIMEOUT        = int(os.environ.get("REQUEST_TIMEOUT", "120"))
UPLOAD_TIMEOUT         = int(os.environ.get("UPLOAD_TIMEOUT", "300"))
WS_IDLE_TIMEOUT        = int(os.environ.get("WS_IDLE_TIMEOUT", "120"))
MAX_WS_PER_GROUP       = int(os.environ.get("MAX_WS_PER_GROUP", "200"))
MAX_WS_TOTAL           = int(os.environ.get("MAX_WS_TOTAL", "500"))
MAX_WS_PER_IP          = int(os.environ.get("MAX_WS_PER_IP", "20"))
MAX_CONCURRENT_UPLOADS = int(os.environ.get("MAX_CONCURRENT_UPLOADS", "20"))
REQUIRE_CHUNK_HASH     = os.environ.get("REQUIRE_CHUNK_HASH", "1") != "0"
ALLOW_UNSIGNED_DH      = os.environ.get("ALLOW_UNSIGNED_DH", "0") == "1"
TRUST_PROXY            = os.environ.get("TRUST_PROXY", "0") == "1"
SOCKET_TIMEOUT         = max(REQUEST_TIMEOUT, UPLOAD_TIMEOUT) + 10

_ALLOWED_POLICIES = ("admin", "owner", "everyone")
FILE_DOWNLOAD_POLICY = os.environ.get("FILE_DOWNLOAD_POLICY", "admin")
if FILE_DOWNLOAD_POLICY not in _ALLOWED_POLICIES: FILE_DOWNLOAD_POLICY = "admin"
_ALLOWED_VIS = ("all", "view", "self")

P = "amber brave calm dusk ember frost gold haze iron jade kite lunar moss nova opal pine".split()
S = "arrow brook cedar delta eagle field grove harbor island jungle knoll lantern meadow noble orbit peak".split()
WORDS = [p + s for p in P for s in S]
WSET = set(WORDS); assert len(WSET) == 256

# ---------- Logging ----------
def log_json(**kw):
    kw["ts"] = round(time.time(), 3)
    try:
        sys.stderr.write(json.dumps(kw, default=str) + "\n")
        sys.stderr.flush()
    except Exception:
        pass

# ---------- Permission helpers ----------
def _harden(path, mode):
    if not os.path.exists(path):
        return
    try:
        os.chmod(path, mode)
    except OSError as e:
        log_json(level="error", msg="chmod failed", path=path, error=str(e))
        raise SystemExit(f"refusing to run: cannot chmod {path}: {e}")

def _verify_secret_perms():
    for p in (PEPPER_FILE, HMAC_KEY_FILE, DBPATH,
              DBPATH + "-wal", DBPATH + "-shm"):
        if os.path.exists(p):
            st = os.stat(p)
            if st.st_mode & 0o077:
                raise SystemExit(
                    f"insecure permissions on {p}: {oct(st.st_mode & 0o777)} (expected 0600)")
    for d in (DATA, FILES):
        if os.path.isdir(d):
            st = os.stat(d)
            if st.st_mode & 0o077:
                raise SystemExit(
                    f"insecure permissions on {d}: {oct(st.st_mode & 0o777)} (expected 0700)")

# ---------- Pepper ----------
PEPPER_FILE = os.environ.get("PEPPER_PATH") or os.path.join(DATA, "pepper")

def _save_peppers(p):
    tmp = PEPPER_FILE + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(p, f); f.flush(); os.fsync(f.fileno())
    finally:
        pass
    os.replace(tmp, PEPPER_FILE)
    _harden(PEPPER_FILE, 0o600)

def _load_or_init_peppers():
    if not os.path.exists(PEPPER_FILE):
        p = {"current": 1, "peppers": {"1": secrets.token_bytes(32).hex()}}
        _save_peppers(p); return p
    with open(PEPPER_FILE, "rb") as f: raw = f.read()
    try:
        j = json.loads(raw)
        if isinstance(j, dict) and "peppers" in j and "current" in j: return j
    except (json.JSONDecodeError, UnicodeDecodeError): pass
    p = {"current": 1, "peppers": {"1": raw.hex()}}
    _save_peppers(p)
    log_json(level="info", msg="migrated legacy pepper → JSON v1")
    return p

_pp = _load_or_init_peppers()
PEPPERS = {int(k): bytes.fromhex(v) for k, v in _pp["peppers"].items()}
PEPPER_CURRENT = int(_pp["current"])
if PEPPER_CURRENT not in PEPPERS:
    raise SystemExit(f"[pepper] current v{PEPPER_CURRENT} missing")
_harden(PEPPER_FILE, 0o600)

# ---------- HMAC key ----------
HMAC_KEY_FILE = os.path.join(DATA, "hmac_key")
if not os.path.exists(HMAC_KEY_FILE):
    fd = os.open(HMAC_KEY_FILE, os.O_WRONLY | os.O_CREAT, 0o600)
    try: os.write(fd, secrets.token_bytes(32))
    finally: os.close(fd)
_harden(HMAC_KEY_FILE, 0o600)
HMAC_KEY = open(HMAC_KEY_FILE, "rb").read()

def pub_hmac(mid, pub_json):
    return hmac.new(HMAC_KEY, f"{mid}:{pub_json}".encode(), hashlib.sha256).hexdigest()

def ip_bucket(ip):
    day = time.strftime("%Y%m%d").encode()
    return hmac.new(HMAC_KEY, ip.encode() + b":" + day, hashlib.sha256).hexdigest()[:16]

# ---------- DB ----------
DBPATH = os.path.join(DATA, "chat.db")
class DB(threading.local):
    def _c(self):
        if not hasattr(self, "c"):
            self.c = sqlite3.connect(DBPATH, timeout=10, isolation_level=None)
            self.c.execute("PRAGMA foreign_keys=ON")
            self.c.execute("PRAGMA journal_mode=WAL")
        return self.c
    def execute(self, *a): return self._c().execute(*a)
    def executescript(self, *a): return self._c().executescript(*a)

def check_schema():
    want = {"groups":["id","gid_hash","invite_v","admin_v","created"],
            "members":["id","group_id","pub","fp","role","token_h","joined"],
            "messages":["id","group_id","member_id","iv","ct","ts"]}
    if not os.path.exists(DBPATH): return
    try:
        c = sqlite3.connect(DBPATH)
        have = {t:[r[1] for r in c.execute(f"PRAGMA table_info({t})")] for t in want}
        c.close()
    except Exception as e:
        log_json(level="warn", msg="schema inspect failed", error=str(e)); return
    bad = [t for t in want if have[t] and not all(w in have[t] for w in want[t])]
    if bad:
        bak = DBPATH + f".old-{int(time.time())}"
        for ext in ("","-wal","-shm"):
            if os.path.exists(DBPATH + ext): os.rename(DBPATH + ext, bak + ext)
        log_json(level="warn", msg="incompatible schema, backed up", tables=bad, backup=bak)
check_schema()

db = DB()
db.executescript("""
PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS groups(id TEXT PRIMARY KEY, gid_hash TEXT UNIQUE NOT NULL,
  invite_v TEXT NOT NULL, admin_v TEXT NOT NULL, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS members(id TEXT PRIMARY KEY, group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  pub TEXT NOT NULL, fp TEXT NOT NULL, role TEXT NOT NULL, token_h TEXT UNIQUE NOT NULL, joined INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  member_id TEXT NOT NULL, iv TEXT NOT NULL, ct TEXT NOT NULL, ts INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_messages_gid_id ON messages(group_id, id);
CREATE INDEX IF NOT EXISTS idx_messages_ts ON messages(ts);
CREATE TABLE IF NOT EXISTS group_state(group_id TEXT PRIMARY KEY REFERENCES groups(id) ON DELETE CASCADE,
  epoch INTEGER NOT NULL, rot INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS wraps(member_id TEXT NOT NULL, epoch INTEGER NOT NULL,
  group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  from_id TEXT NOT NULL, blob TEXT NOT NULL, PRIMARY KEY(member_id, epoch));
CREATE TABLE IF NOT EXISTS blocks(group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  fp TEXT NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY(group_id, fp));
CREATE TABLE IF NOT EXISTS files(fid TEXT PRIMARY KEY, group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  member_id TEXT NOT NULL, total INTEGER NOT NULL, bytes INTEGER NOT NULL, ts INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_files_ts ON files(ts);
CREATE TABLE IF NOT EXISTS file_chunks(
  fid TEXT NOT NULL REFERENCES files(fid) ON DELETE CASCADE,
  idx INTEGER NOT NULL, sha256 TEXT NOT NULL, bytes INTEGER NOT NULL,
  PRIMARY KEY(fid, idx));
CREATE INDEX IF NOT EXISTS idx_file_chunks_fid ON file_chunks(fid);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  actor_id TEXT NOT NULL, kind TEXT NOT NULL, target_fp TEXT, ts INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS rate_limits(key TEXT NOT NULL, bucket TEXT NOT NULL, ts INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_rate_limits ON rate_limits(key, bucket, ts);
""")

for stmt in [
    f"ALTER TABLE groups ADD COLUMN file_policy TEXT NOT NULL DEFAULT '{FILE_DOWNLOAD_POLICY}'",
    "ALTER TABLE groups ADD COLUMN name TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE files ADD COLUMN vis TEXT NOT NULL DEFAULT 'all'",
    "ALTER TABLE files ADD COLUMN reserved INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE files ADD COLUMN published INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE files ADD COLUMN first_seen INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE messages ADD COLUMN cid TEXT",
    "ALTER TABLE members ADD COLUMN pub_sig TEXT",
    "ALTER TABLE members ADD COLUMN token_h_prev TEXT",
    "ALTER TABLE members ADD COLUMN token_h_prev_ts INTEGER",
]:
    try: db.execute(stmt)
    except sqlite3.OperationalError: pass

try:
    db.execute("UPDATE files SET first_seen=ts WHERE first_seen=0")
    db.execute(
        "UPDATE files SET published=1 "
        "WHERE published=0 AND total = (SELECT COUNT(*) FROM file_chunks WHERE fid=files.fid)")
except sqlite3.OperationalError:
    pass

try: db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_cid ON messages(group_id, cid) WHERE cid IS NOT NULL")
except sqlite3.OperationalError: pass

_harden(DATA, 0o700)
os.makedirs(FILES, mode=0o700, exist_ok=True)
_harden(FILES, 0o700)
for _p in (DBPATH, DBPATH + "-wal", DBPATH + "-shm"):
    if os.path.exists(_p): _harden(_p, 0o600)
_verify_secret_perms()

if not REQUIRE_CHUNK_HASH:
    log_json(level="warn",
             msg="REQUIRE_CHUNK_HASH=0 — clients will refuse unverified downloads")

# ---------- Globals ----------
lock = threading.Lock()
_rl_lock = threading.Lock()
_upload_sem = threading.Semaphore(MAX_CONCURRENT_UPLOADS)
_last_rl_cleanup = [0.0]
_rl_err_count = [0]
USE_HTTPS = [False]

_ws_ip_counts = {}
_ws_ip_lock = threading.Lock()

class _Forbidden(Exception): pass
class _QuotaExceeded(Exception): pass
sha = lambda s: hashlib.sha256(s.encode()).hexdigest()

# ---------- Helpers ----------
def gid_hash(words, version=None):
    v = version if version is not None else PEPPER_CURRENT
    return hmac.new(PEPPERS[v], " ".join(words).encode(), hashlib.sha256).hexdigest()

def find_group_by_gid(words):
    versions = [PEPPER_CURRENT] + sorted([v for v in PEPPERS if v != PEPPER_CURRENT], reverse=True)
    for v in versions:
        h = gid_hash(words, v)
        row = db.execute("SELECT id,invite_v,admin_v FROM groups WHERE gid_hash=?", (h,)).fetchone()
        if row: return row
    return None

def _ec(j):
    return (isinstance(j, dict) and j.get("kty") == "EC" and j.get("crv") == "P-256"
            and all(isinstance(j.get(k), str) and 40 < len(j[k]) < 50 for k in ("x","y")))

def valid_pub(j):
    return _ec(j) and _ec(j.get("dh"))

def valid_pub_with_sig(j):
    if not valid_pub(j): return False
    if ALLOW_UNSIGNED_DH and "dh_sig" not in j: return True
    return isinstance(j.get("dh_sig"), str) and 80 <= len(j["dh_sig"]) <= 200

def _has_good_dh(pub):
    if not isinstance(pub, dict) or "dh" not in pub: return False
    sig = pub.get("dh_sig")
    return isinstance(sig, str) and 80 <= len(sig) <= 200

def clean_pub(j):
    out = {**{k: j[k] for k in ("kty","crv","x","y")}}
    out["dh"] = {k: j["dh"][k] for k in ("kty","crv","x","y")}
    if "dh_sig" in j: out["dh_sig"] = j["dh_sig"]
    return out

def is_hex64(s):
    return isinstance(s, str) and len(s) == 64 and all(c in "0123456789abcdef" for c in s)

def is_hex32(s):
    return isinstance(s, str) and len(s) == 32 and all(c in "0123456789abcdef" for c in s)

def fp_of(pub):
    return sha(json.dumps({k: pub[k] for k in ("crv","kty","x","y")}, sort_keys=True))[:16]

def new_member(cur, gid, pub, role):
    token = secrets.token_urlsafe(32); mid = secrets.token_hex(8); fp = fp_of(pub)
    pub_json = json.dumps(clean_pub(pub), sort_keys=True)
    pub_sig = pub_hmac(mid, pub_json)
    cur.execute(
        "INSERT INTO members(id,group_id,pub,pub_sig,fp,role,token_h,joined) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (mid, gid, pub_json, pub_sig, fp, role, sha(token), int(time.time())))
    return token, mid, fp

def audit(gid, actor, kind, target_fp=None):
    try: db.execute("INSERT INTO events(group_id,actor_id,kind,target_fp,ts) VALUES(?,?,?,?,?)",
                    (gid, actor, kind, target_fp, int(time.time())))
    except Exception as e: log_json(level="warn", msg="audit failed", error=str(e))

def get_policy(gid):
    try:
        row = db.execute("SELECT file_policy FROM groups WHERE id=?", (gid,)).fetchone()
        if row and row[0] in _ALLOWED_POLICIES: return row[0]
    except Exception: pass
    return FILE_DOWNLOAD_POLICY

def get_name(gid):
    try:
        row = db.execute("SELECT name FROM groups WHERE id=?", (gid,)).fetchone()
        if row and row[0]: return row[0]
    except Exception: pass
    return ""

def can_view(m, uploader_mid, vis):
    return m[0] == uploader_mid if vis == "self" else True

def can_download(m, uploader_mid, vis, policy):
    if vis == "self": return m[0] == uploader_mid
    if vis == "view": return False
    if m[0] == uploader_mid: return True
    if m[2] == "admin": return True
    if policy == "everyone": return True
    return False

@contextmanager
def tx():
    with lock:
        db.execute("BEGIN IMMEDIATE")
        try: yield; db.execute("COMMIT")
        except Exception:
            try: db.execute("ROLLBACK")
            except sqlite3.Error: pass
            raise

def limited(key, bucket, limit, window=60):
    if ":" in key or "." in key: key = ip_bucket(key)
    now = int(time.time())
    if now - _last_rl_cleanup[0] > 300:
        _last_rl_cleanup[0] = now
        try: db.execute("DELETE FROM rate_limits WHERE ts < ?", (now - 3600,))
        except sqlite3.Error: pass
    cutoff = now - window
    try:
        with _rl_lock:
            n = db.execute("SELECT COUNT(*) FROM rate_limits WHERE key=? AND bucket=? AND ts>?",
                           (key, bucket, cutoff)).fetchone()[0]
            if n >= limit: return True
            db.execute("INSERT INTO rate_limits(key,bucket,ts) VALUES(?,?,?)", (key, bucket, now))
        _rl_err_count[0] = 0
        return False
    except sqlite3.Error as e:
        _rl_err_count[0] += 1
        log_json(level="warn", msg="ratelimit error", error=str(e))
        return _rl_err_count[0] >= 3

def cleanup_rate_limits():
    try: db.execute("DELETE FROM rate_limits WHERE ts < ?", (int(time.time()) - 3600,))
    except Exception as e: log_json(level="warn", msg="ratelimit-cleanup", error=str(e))

def wal_checkpoint():
    try:
        r = db.execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone()
        if r and r[0]:
            log_json(level="warn", msg="wal checkpoint busy", log=r[1], ckpt=r[2])
        wp = DBPATH + "-wal"
        if os.path.exists(wp) and os.path.getsize(wp) > 50 * 1024 * 1024:
            log_json(level="warn", msg="wal large", bytes=os.path.getsize(wp))
    except Exception as e:
        log_json(level="warn", msg="wal checkpoint failed", error=str(e))

def disk_usage():
    try:
        st = os.statvfs(DATA)
        total = st.f_frsize * st.f_blocks; free = st.f_frsize * st.f_bavail
        return {"total_mb": round(total/1048576,1), "free_mb": round(free/1048576,1),
                "used_pct": round((total - free)/total*100, 1) if total else 0}
    except Exception: return {}

def has_disk_space(needed):
    try:
        st = os.statvfs(DATA)
        return st.f_frsize * st.f_bavail >= needed * 1.5 + 5 * 1024 * 1024
    except Exception: return True

def sweep_stale_uploads():
    cutoff = int(time.time()) - STALE_FILE_SECONDS
    try:
        rows = db.execute("SELECT fid,group_id,total FROM files WHERE ts<? AND published=0", (cutoff,)).fetchall()
    except Exception:
        return 0
    removed = 0
    for fid, gid, total in rows:
        d = os.path.join(FILES, gid)
        try:
            have_disk = sum(1 for i in range(total) if os.path.exists(os.path.join(d, f"{fid}.{i}")))
        except Exception:
            have_disk = 0
        try:
            have_db = db.execute("SELECT COUNT(*) FROM file_chunks WHERE fid=?", (fid,)).fetchone()[0]
        except Exception:
            have_db = 0
        if have_disk < total or have_db < total:
            for i in range(total):
                try: os.remove(os.path.join(d, f"{fid}.{i}"))
                except OSError: pass
            try:
                db.execute("DELETE FROM files WHERE fid=?", (fid,))
                removed += 1
            except Exception:
                pass
    if removed: log_json(level="info", msg="swept stale uploads", count=removed)
    return removed

def sweep_stale_reservations():
    now = int(time.time())
    soft_cutoff = now - STALE_FILE_SECONDS
    hard_cutoff = now - UPLOAD_DEADLINE_SECONDS
    try:
        stale = db.execute(
            "SELECT fid,group_id FROM files "
            "WHERE published=0 AND (first_seen<? OR ts<?)",
            (hard_cutoff, soft_cutoff)).fetchall()
    except Exception:
        return
    for fid, gid in stale:
        d = os.path.join(FILES, gid)
        if os.path.isdir(d):
            for fn in os.listdir(d):
                if fn.startswith(fid + "."):
                    try: os.remove(os.path.join(d, fn))
                    except OSError: pass
        try: db.execute("DELETE FROM files WHERE fid=?", (fid,))
        except Exception: pass

def sweep_orphan_chunks():
    removed = 0
    try: gdirs = [d for d in os.listdir(FILES) if os.path.isdir(os.path.join(FILES, d))] if os.path.isdir(FILES) else []
    except Exception: return 0
    known = {r[0] for r in db.execute("SELECT id FROM groups").fetchall()}
    for gdir in gdirs:
        gpath = os.path.join(FILES, gdir)
        if gdir not in known:
            try:
                n = len(os.listdir(gpath)); shutil.rmtree(gpath, ignore_errors=True)
                removed += n; log_json(level="info", msg="removed orphan dir", gid=gdir, files=n)
            except Exception: pass
            continue
        for fname in os.listdir(gpath):
            fp = os.path.join(gpath, fname)
            if fname.endswith(".tmp"):
                try:
                    if os.path.getmtime(fp) < time.time() - 3600:
                        os.remove(fp); removed += 1
                except OSError: pass
                continue
            m_ = re.fullmatch(r"([0-9a-f]{32})\.(\d+)", fname)
            if not m_:
                try: os.remove(fp); removed += 1
                except OSError: pass
                continue
            fid = m_.group(1)
            try: row = db.execute("SELECT 1 FROM files WHERE fid=?", (fid,)).fetchone()
            except Exception: continue
            if not row:
                try: os.remove(fp); removed += 1
                except OSError: pass
    if removed: log_json(level="info", msg="removed orphan chunks", count=removed)
    return removed

def apply_retention():
    if RETENTION_DAYS <= 0: return 0
    cutoff = int(time.time()) - RETENTION_DAYS * 86400
    dmsgs = 0; dfiles = 0
    try:
        dmsgs = db.execute("DELETE FROM messages WHERE ts<?", (cutoff,)).rowcount or 0
        for fid, gid in db.execute("SELECT fid,group_id FROM files WHERE ts<?", (cutoff,)).fetchall():
            for i in range(MAX_CHUNKS):
                try: os.remove(os.path.join(FILES, gid, f"{fid}.{i}"))
                except OSError: pass
            try: db.execute("DELETE FROM files WHERE fid=?", (fid,)); dfiles += 1
            except Exception: pass
    except Exception as e: log_json(level="warn", msg="retention error", error=str(e))
    if dmsgs or dfiles: log_json(level="info", msg="retention applied", msgs=dmsgs, files=dfiles)
    return dmsgs

def verify_group_cleanup(gid):
    issues = []
    try:
        for t in ("members","messages","files","wraps","group_state","blocks","events","file_chunks"):
            if t == "file_chunks":
                n = db.execute("SELECT COUNT(*) FROM file_chunks fc JOIN files f ON fc.fid=f.fid WHERE f.group_id=?", (gid,)).fetchone()[0]
            else:
                n = db.execute(f"SELECT COUNT(*) FROM {t} WHERE group_id=?", (gid,)).fetchone()[0]
            if n: issues.append(f"{t}:{n}")
        gdir = os.path.join(FILES, gid)
        if os.path.isdir(gdir):
            fs = os.listdir(gdir)
            if fs: issues.append(f"files:{len(fs)}")
    except Exception as e: issues.append(f"check:{e}")
    log_json(level="info", msg="cleanup verify", gid=gid, issues=issues or None)
    return issues

def maintenance_loop():
    while True:
        try:
            try: _verify_secret_perms()
            except SystemExit as e:
                log_json(level="error", msg="secret perms drifted", error=str(e))
            sweep_stale_uploads(); sweep_stale_reservations()
            sweep_orphan_chunks(); apply_retention()
            cleanup_rate_limits(); wal_checkpoint()
            du = disk_usage()
            if du.get("used_pct", 0) >= DISK_WARN_PCT:
                log_json(level="warn", msg="disk usage high", pct=du["used_pct"])
        except Exception as e:
            log_json(level="error", msg="maintenance error", error=str(e))
        time.sleep(MAINT_INTERVAL)
threading.Thread(target=maintenance_loop, daemon=True).start()

def reservation_loop():
    while True:
        try: sweep_stale_reservations()
        except Exception as e: log_json(level="warn", msg="reservation sweep error", error=str(e))
        time.sleep(60)
threading.Thread(target=reservation_loop, daemon=True).start()

def backfill_pub_sig():
    try:
        rows = db.execute("SELECT id,pub FROM members WHERE pub_sig IS NULL").fetchall()
        for mid, pub_json in rows:
            db.execute("UPDATE members SET pub_sig=? WHERE id=?", (pub_hmac(mid, pub_json), mid))
        if rows: log_json(level="info", msg="backfilled pub_sig", count=len(rows))
    except sqlite3.Error as e:
        log_json(level="warn", msg="pub_sig backfill failed", error=str(e))
backfill_pub_sig()

# ---------- WebSocket ----------
ws_clients = {}; ws_presence = {}; ws_lock = threading.Lock()
class WSConn:
    def __init__(self, sock, gid, mid):
        self.sock = sock; self.gid = gid; self.mid = mid; self.lock = threading.Lock()
    def _send(self, opcode, payload=b""):
        n = len(payload); h = bytearray([0x80 | opcode])
        if n < 126: h.append(n)
        elif n < 65536: h.append(126); h += struct.pack(">H", n)
        else: h.append(127); h += struct.pack(">Q", n)
        with self.lock:
            try: self.sock.sendall(bytes(h) + payload)
            except OSError: pass
    def text(self, s): self._send(0x1, s.encode())
    def close(self, code=1000): self._send(0x8, struct.pack(">H", code))

def ws_join(gid, c):
    with ws_lock: ws_clients.setdefault(gid, set()).add(c)
def ws_leave(gid, c):
    with ws_lock:
        s = ws_clients.get(gid)
        if s: s.discard(c)
        if s is not None and not s: ws_clients.pop(gid, None)
def ws_online(gid):
    with ws_lock: return list(ws_presence.get(gid, {}).keys())
def ws_add_presence(gid, mid, conn):
    with ws_lock:
        d = ws_presence.setdefault(gid, {}); s = d.setdefault(mid, set()); s.add(conn)
        return len(s) == 1
def ws_remove_presence(gid, mid, conn):
    with ws_lock:
        d = ws_presence.get(gid, {}); s = d.get(mid)
        if not s: return False
        s.discard(conn)
        if not s:
            d.pop(mid, None)
            if not d: ws_presence.pop(gid, None)
            return True
        return False
def ws_clear_presence(gid, mid=None):
    with ws_lock:
        if mid is None: ws_presence.pop(gid, None)
        else:
            d = ws_presence.get(gid, {}); d.pop(mid, None)
            if not d: ws_presence.pop(gid, None)
def ws_broadcast(gid, kind="new"):
    with ws_lock: peers = list(ws_clients.get(gid, ()))
    msg = json.dumps({"type": kind})
    for p in peers: p.text(msg)
def broadcast_presence(gid):
    with ws_lock: peers = list(ws_clients.get(gid, ()))
    online = ws_online(gid); msg = json.dumps({"type":"presence","online":online})
    for p in peers: p.text(msg)
def broadcast_typing(gid, mid):
    with ws_lock: peers = [p for p in ws_clients.get(gid, ()) if p.mid != mid]
    msg = json.dumps({"type":"typing","from":mid})
    for p in peers: p.text(msg)
def ws_close_member(gid, mid):
    with ws_lock: peers = list(ws_clients.get(gid, ()))
    for p in peers:
        if p.mid == mid: p.close(1001)
    ws_clear_presence(gid, mid)
def ws_close_group(gid):
    with ws_lock: peers = list(ws_clients.get(gid, ()))
    for p in peers: p.close(1001)
    ws_clear_presence(gid)

class H(BaseHTTPRequestHandler):
    server_version = "Srv"; sys_version = ""
    _req_id = ""

    def setup(self):
        super().setup()
        self._req_id = uuid.uuid4().hex[:12]

    def log_message(self, fmt, *args):
        log_json(level="info", req=self._req_id, method=self.command,
                 path=self.path.split("?")[0], msg=fmt % args)

    def client_ip(self):
        if TRUST_PROXY:
            xff = self.headers.get("X-Forwarded-For", "")
            if xff: return xff.split(",")[0].strip()
            xri = self.headers.get("X-Real-IP", "")
            if xri: return xri
        return self.client_address[0]

    def handle_one_request(self):
        try:
            try: self.connection.settimeout(SOCKET_TIMEOUT)
            except (AttributeError, OSError): pass
            super().handle_one_request()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError,
                TimeoutError, OSError):
            self.close_connection = True

    def _is_https(self): return USE_HTTPS[0]

    def send(self, code, body, ctype="application/json", extra_headers=None):
        try:
            b = body if isinstance(body, bytes) else json.dumps(body).encode()
            host = self.headers.get("Host", "localhost")
            if not re.fullmatch(r"[A-Za-z0-9.\-:\[\]]+", host): host = "localhost"
            ws_origin = f"{'wss' if USE_HTTPS[0] else 'ws'}://{host}"
            csp = (
                "default-src 'none'; script-src 'self'; style-src 'self'; "
                f"connect-src 'self' {ws_origin}; "
                "img-src 'self' blob:; media-src blob:; "
                "base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
            )
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(b)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("X-Request-ID", self._req_id)
            if self._is_https():
                self.send_header("Strict-Transport-Security", "max-age=31536000")
            self.send_header("Content-Security-Policy", csp)
            if extra_headers:
                for k, v in extra_headers.items(): self.send_header(k, v)
            if code >= 500:
                log_json(level="error", req=self._req_id, method=self.command,
                         path=self.path.split("?")[0], code=code,
                         body=b[:200].decode(errors="replace"))
            self.end_headers(); self.wfile.write(b)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError): pass

    def _read_body_bytes(self, n, timeout):
        deadline = time.monotonic() + timeout
        chunks = []; remaining = n
        reader = getattr(self.rfile, "read1", None) or self.rfile.read
        while remaining > 0:
            if time.monotonic() > deadline:
                self.close_connection = True
                raise TimeoutError("body read timeout")
            try: chunk = reader(min(remaining, 65536))
            except (TimeoutError, OSError) as e:
                self.close_connection = True
                raise TimeoutError(f"body read failed: {e}")
            if not chunk:
                self.close_connection = True
                raise OSError("truncated body")
            chunks.append(chunk); remaining -= len(chunk)
        return b"".join(chunks)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            self.close_connection = True
            raise ValueError("too large")
        data = self._read_body_bytes(n, REQUEST_TIMEOUT) if n else b""
        d = json.loads(data or b"{}")
        if not isinstance(d, dict): raise ValueError("bad json")
        return d

    def member(self):
        t = self.headers.get("X-Token", "")
        if not (20 < len(t) < 80): return None
        th = sha(t)
        row = db.execute("SELECT id,group_id,role FROM members WHERE token_h=?", (th,)).fetchone()
        if row: return row
        return db.execute(
            "SELECT id,group_id,role FROM members WHERE token_h_prev=? AND token_h_prev_ts > ?",
            (th, int(time.time()) - 600)).fetchone()

    def _read_ws_frame(self):
        h = self.rfile.read(2)
        if not h or len(h) < 2: return None
        fin = (h[0] & 0x80) != 0; rsv = h[0] & 0x70; op = h[0] & 0x0F
        masked = (h[1] & 0x80) != 0; n = h[1] & 0x7F
        if rsv != 0 or not masked or not fin: return False
        if op not in (0x1, 0x2, 0x8, 0x9, 0xA): return False
        if n == 126: n = struct.unpack(">H", self.rfile.read(2))[0]
        elif n == 127: n = struct.unpack(">Q", self.rfile.read(8))[0]
        if n > 4 * 1024: return False
        mask = self.rfile.read(4)
        if len(mask) != 4: return None
        data = self.rfile.read(n) if n else b""
        if data: data = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        return (op, data)

    def websocket(self):
        ip = self.client_ip()
        origin = self.headers.get("Origin", "")
        host = self.headers.get("Host", "")
        if origin and host:
            try:
                o = urlparse(origin)
                if o.netloc and o.netloc != host:
                    return self.send(403, {"error": "bad origin"})
            except Exception:
                return self.send(400, {"error": "bad origin"})
        if self.headers.get("Upgrade", "").lower() != "websocket":
            return self.send(400, {"error": "expected websocket upgrade"})
        key = self.headers.get("Sec-WebSocket-Key")
        prot = (self.headers.get("Sec-WebSocket-Protocol") or "").strip()
        m = db.execute("SELECT id,group_id,role FROM members WHERE token_h=?",
                       (sha(prot),)).fetchone() if 20 < len(prot) < 80 else None
        if not m and prot:
            m = db.execute("SELECT id,group_id,role FROM members WHERE token_h_prev=? AND token_h_prev_ts > ?",
                           (sha(prot), int(time.time()) - 600)).fetchone()
        if not key or not m: return self.send(401, {"error": "unauthorized"})
        with _ws_ip_lock:
            if _ws_ip_counts.get(ip, 0) >= MAX_WS_PER_IP:
                return self.send(429, {"error": "too many connections from this IP"})
        gid = m[1]
        with ws_lock:
            total_ws = sum(len(s) for s in ws_clients.values())
            group_ws = len(ws_clients.get(gid, ()))
        if total_ws >= MAX_WS_TOTAL:     return self.send(503, {"error": "server at capacity"})
        if group_ws >= MAX_WS_PER_GROUP: return self.send(503, {"error": "too many connections for this group"})
        accept = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
        self.send_response_only(101, "Switching Protocols")
        self.send_header("Upgrade", "websocket")
        self.send_header("Connection", "Upgrade")
        self.send_header("Sec-WebSocket-Accept", accept)
        self.send_header("Sec-WebSocket-Protocol", prot)
        self.end_headers()
        try: self.wfile.flush()
        except Exception: pass
        mid = m[0]
        try: self.connection.settimeout(WS_IDLE_TIMEOUT)
        except (AttributeError, OSError): pass
        ws = WSConn(self.connection, gid, mid)
        ws_join(gid, ws); ws_add_presence(gid, mid, ws)
        with _ws_ip_lock:
            _ws_ip_counts[ip] = _ws_ip_counts.get(ip, 0) + 1
        broadcast_presence(gid)
        try:
            while True:
                fr = self._read_ws_frame()
                if fr is None: break
                if fr is False:
                    ws.close(1002); break
                op, data = fr
                if op == 0x8: break
                if op == 0x9: ws._send(0xA, data); continue
                if op == 0x1:
                    try: ev = json.loads(data.decode())
                    except Exception: continue
                    t = ev.get("type")
                    if t == "typing" and not limited(mid, "typing", 30, 60): broadcast_typing(gid, mid)
                    elif t == "ping": ws.text(json.dumps({"type":"pong"}))
        except Exception: pass
        finally:
            ws_leave(gid, ws)
            with _ws_ip_lock:
                n = _ws_ip_counts.get(ip, 0) - 1
                if n > 0: _ws_ip_counts[ip] = n
                else: _ws_ip_counts.pop(ip, None)
            if ws_remove_presence(gid, mid, ws): broadcast_presence(gid)
            self.close_connection = True

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/healthz":          return self.health()
        if u.path == "/metrics":          return self.metrics()
        if u.path == "/api/admin/health": return self.admin_health()
        if u.path == "/api/ws":           return self.websocket()
        if u.path == "/api/messages":
            m = self.member()
            if not m: return self.send(401, {"error": "unauthorized"})
            if limited(m[0], "poll", 60): return self.send(429, {"error": "slow down"})
            try: after = int(parse_qs(u.query).get("after", ["0"])[0])
            except ValueError: return self.send(400, {"error": "bad request"})
            after = max(0, min(after, 2**31))
            rows = db.execute(
                "SELECT id,member_id,iv,ct,ts,cid FROM messages "
                "WHERE group_id=? AND id>? ORDER BY id LIMIT 200",
                (m[1], after)).fetchall()
            gs = db.execute("SELECT epoch,rot FROM group_state WHERE group_id=?", (m[1],)).fetchone() or (0,0)
            return self.send(200, {"me": m[0], "role": m[2], "epoch": gs[0], "rot": gs[1],
                "online": ws_online(m[1]), "file_policy": get_policy(m[1]),
                "name": get_name(m[1]),
                "messages": [dict(id=r[0], m=r[1], iv=r[2], ct=r[3], ts=r[4], cid=r[5]) for r in rows]})
        if u.path == "/api/file":         return self.download(u.query)
        if u.path == "/api/file/status":
            m = self.member()
            if not m: return self.send(401, {"error": "unauthorized"})
            if limited(m[0], "filestat", 120): return self.send(429, {"error": "slow down"})
            return self.file_status(u.query)
        if u.path == "/api/state":        return self.state()
        if u.path == "/api/admin/members":return self.admin_members()
        if u.path == "/api/admin/events": return self.admin_events()
        path = u.path.lstrip("/") or "index.html"
        if path in ("create-group","join-group","chat"): path += ".html"
        full = os.path.realpath(os.path.join(STATIC, path))
        if not full.startswith(STATIC + os.sep) or not os.path.isfile(full):
            return self.send(404, b"Not found", "text/plain")
        ct = {".html":"text/html; charset=utf-8",".css":"text/css",".js":"application/javascript"}.get(
            os.path.splitext(full)[1], "application/octet-stream")
        self.send(200, open(full, "rb").read(), ct)

    def health(self):
        self.send(200, {"ok": True})

    def metrics(self):
        with lock:
            try:
                groups = db.execute("SELECT COUNT(*) FROM groups").fetchone()[0]
                members = db.execute("SELECT COUNT(*) FROM members").fetchone()[0]
                messages = db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
                files = db.execute("SELECT COUNT(*) FROM files").fetchone()[0]
                file_bytes = db.execute("SELECT COALESCE(SUM(bytes),0) FROM files").fetchone()[0]
            except Exception:
                return self.send(500, b"# error\n", "text/plain")
        with ws_lock:
            ws_total = sum(len(s) for s in ws_clients.values())
        du = disk_usage()
        lines = [
            "# HELP e2ee_groups_total Active groups",
            "# TYPE e2ee_groups_total gauge", f"e2ee_groups_total {groups}",
            "# HELP e2ee_members_total Members across all groups",
            "# TYPE e2ee_members_total gauge", f"e2ee_members_total {members}",
            "# HELP e2ee_messages_total Stored messages",
            "# TYPE e2ee_messages_total gauge", f"e2ee_messages_total {messages}",
            "# HELP e2ee_files_total Stored files",
            "# TYPE e2ee_files_total gauge", f"e2ee_files_total {files}",
            "# HELP e2ee_file_bytes_total Bytes used by files",
            "# TYPE e2ee_file_bytes_total gauge", f"e2ee_file_bytes_total {file_bytes}",
            "# HELP e2ee_ws_connections Live WebSocket connections",
            "# TYPE e2ee_ws_connections gauge", f"e2ee_ws_connections {ws_total}",
        ]
        if du.get("used_pct") is not None:
            lines += ["# TYPE e2ee_disk_used_pct gauge", f"e2ee_disk_used_pct {du['used_pct']}"]
        self.send(200, ("\n".join(lines) + "\n").encode(), "text/plain; version=0.0.4")

    def admin_health(self):
        m = self.admin()
        if not m: return
        gid = m[1]; stats = {}; file_bytes = 0; self_files = view_files = 0
        try:
            stats["members"]  = db.execute("SELECT COUNT(*) FROM members  WHERE group_id=?", (gid,)).fetchone()[0]
            stats["messages"] = db.execute("SELECT COUNT(*) FROM messages WHERE group_id=?", (gid,)).fetchone()[0]
            stats["files"]    = db.execute("SELECT COUNT(*) FROM files    WHERE group_id=?", (gid,)).fetchone()[0]
            file_bytes = db.execute("SELECT COALESCE(SUM(bytes),0) FROM files WHERE group_id=?", (gid,)).fetchone()[0]
            self_files = db.execute("SELECT COUNT(*) FROM files WHERE group_id=? AND vis='self'", (gid,)).fetchone()[0]
            view_files = db.execute("SELECT COUNT(*) FROM files WHERE group_id=? AND vis='view'", (gid,)).fetchone()[0]
        except Exception: pass
        with ws_lock: group_ws = len(ws_clients.get(gid, ()))
        self.send(200, {"ok": True, "disk": disk_usage(), "group_stats": stats,
                        "file_bytes": file_bytes, "self_files": self_files, "view_files": view_files,
                        "group_ws_connections": group_ws,
                        "retention_days": RETENTION_DAYS,
                        "default_file_policy": FILE_DOWNLOAD_POLICY,
                        "name": get_name(gid),
                        "pepper_version": PEPPER_CURRENT})

    def file_status(self, query):
        m = self.member()
        if not m: return self.send(401, {"error": "unauthorized"})
        q = parse_qs(query); fid = q.get("fid", [""])[0]
        row = db.execute("SELECT group_id,total,member_id,vis,published FROM files WHERE fid=?", (fid,)).fetchone() \
              if re.fullmatch(r"[0-9a-f]{32}", fid) else None
        if not row or row[0] != m[1]: return self.send(404, {"error": "not found"})
        if not row[4] and row[2] != m[0]:
            return self.send(404, {"error": "not found"})
        vis = row[3] or "all"
        if not can_view(m, row[2], vis) and not can_download(m, row[2], vis, get_policy(m[1])):
            return self.send(403, {"error": "not allowed"})
        d = os.path.join(FILES, m[1])
        present = [i for i in range(row[1]) if os.path.exists(os.path.join(d, f"{fid}.{i}"))]
        hashes = {r[0]: r[1] for r in db.execute("SELECT idx,sha256 FROM file_chunks WHERE fid=?", (fid,)).fetchall()}
        return self.send(200, {"total": row[1], "have": present, "vis": vis,
                               "hashes": hashes, "published": bool(row[4])})

    def do_POST(self):
        ip = self.client_ip(); p = urlparse(self.path)
        if p.path == "/api/file/upload": return self.upload(ip, p.query)
        if limited(ip, "all", 120): return self.send(429, {"error": "slow down"})
        try: d = self.body()
        except Exception: return self.send(400, {"error": "invalid request"})
        try:
            if p.path == "/api/create":               return self.create(ip, d)
            if p.path == "/api/join":                 return self.join(ip, d)
            if p.path == "/api/send":                 return self.msg(d)
            if p.path == "/api/auth/rotate-token":    return self.rotate_token()
            if p.path == "/api/rotate":               return self.rotate(d)
            if p.path == "/api/wrap":                 return self.wrap(d)
            if p.path == "/api/purge":                return self.purge(d)
            if p.path == "/api/admin/kick":           return self.remove(d, block=False)
            if p.path == "/api/admin/block":          return self.remove(d, block=True)
            if p.path == "/api/admin/unblock":        return self.unblock(d)
            if p.path == "/api/admin/delete-group":   return self.delete_group(d)
            if p.path == "/api/admin/set-policy":     return self.set_policy(d)
            if p.path == "/api/admin/rename":         return self.rename(d)
            if p.path == "/api/admin/change-credentials": return self.change_credentials(d)
        except sqlite3.Error as e:
            log_json(level="error", msg="db error", path=p.path, error=str(e))
            return self.send(500, {"error": "server error"})
        self.send(404, {"error": "not found"})

    def create(self, ip, d):
        if limited(ip, "create", 5): return self.send(429, {"error": "too many groups"})
        gid = d.get("gid")
        if not (valid_pub_with_sig(d.get("pub")) and isinstance(gid, list) and len(gid) == 8
                and set(gid) <= WSET and is_hex64(d.get("invite_v")) and is_hex64(d.get("admin_v"))):
            return self.send(400, {"error": "invalid request"})
        group_id = secrets.token_hex(16); token = mid = fp = None
        try:
            with tx():
                db.execute("INSERT INTO groups(id,gid_hash,invite_v,admin_v,created,file_policy) VALUES(?,?,?,?,?,?)",
                           (group_id, gid_hash(gid), sha(d["invite_v"]), sha(d["admin_v"]),
                            int(time.time()), FILE_DOWNLOAD_POLICY))
                db.execute("INSERT INTO group_state(group_id,epoch,rot) VALUES(?,0,0)", (group_id,))
                token, mid, fp = new_member(db, group_id, d["pub"], "admin")
        except sqlite3.IntegrityError:
            return self.send(409, {"error": "id collision, retry"})
        except Exception as e:
            log_json(level="error", msg="create failed", error=str(e))
            return self.send(500, {"error": "could not create group"})
        audit(group_id, mid, "create")
        log_json(level="info", msg="group created", gid=group_id[:8], fp=fp, pepper=PEPPER_CURRENT)
        self.send(200, {"token": token, "member_id": mid, "fingerprint": fp, "role": "admin",
                        "file_policy": FILE_DOWNLOAD_POLICY})

    def join(self, ip, d):
        if limited(ip, "join", 10): return self.send(429, {"error": "too many attempts"})
        gid_list = d.get("gid")
        g = find_group_by_gid(gid_list) if isinstance(gid_list, list) and len(gid_list) == 8 and set(gid_list) <= WSET else None
        iv_, av_ = d.get("invite_v"), d.get("admin_v")
        ok = g and is_hex64(iv_) and valid_pub_with_sig(d.get("pub")) and hmac.compare_digest(sha(iv_), g[1])
        if not ok: return self.send(403, {"error": "invalid Group ID or Invite Key"})
        if db.execute("SELECT 1 FROM blocks WHERE group_id=? AND fp=?", (g[0], fp_of(d["pub"]))).fetchone():
            return self.send(403, {"error": "this device is blocked"})
        role = "member"
        if av_:
            if not (is_hex64(av_) and hmac.compare_digest(sha(av_), g[2])):
                return self.send(403, {"error": "invalid Admin Key"})
            role = "admin"
        token, mid, fp = new_member(db, g[0], d["pub"], role)
        ep = (db.execute("SELECT epoch FROM group_state WHERE group_id=?", (g[0],)).fetchone() or (0,))[0]
        audit(g[0], mid, "join"); ws_broadcast(g[0], "refresh")
        self.send(200, {"token": token, "member_id": mid, "fingerprint": fp, "role": role,
                        "file_policy": get_policy(g[0]), "name": get_name(g[0]),
                        "epoch": ep})

    def msg(self, d):
        m = self.member()
        if not m: return self.send(401, {"error": "unauthorized"})
        if limited(self.headers.get("X-Token",""), "msg", 120): return self.send(429, {"error": "slow down"})
        _, rot = db.execute("SELECT epoch,rot FROM group_state WHERE group_id=?", (m[1],)).fetchone() or (0,0)
        if rot: return self.send(409, {"error": "key rotation pending — group is locked until an admin completes rotation"})
        iv, ct, cid = d.get("iv"), d.get("ct"), d.get("cid")
        if cid is not None:
            if not is_hex32(cid): return self.send(400, {"error": "invalid cid (32 hex chars)"})
            existing = db.execute("SELECT id FROM messages WHERE group_id=? AND cid=?", (m[1], cid)).fetchone()
            if existing: return self.send(200, {"ok": True, "id": existing[0], "idempotent": True})
        if not (isinstance(iv, str) and isinstance(ct, str)
                and re.fullmatch(r"\d{1,6}:[A-Za-z0-9+/]{16}", iv) and 0 < len(ct) <= 40000):
            return self.send(400, {"error": "invalid message"})
        try:
            cur = db.execute(
                "INSERT INTO messages(group_id,member_id,iv,ct,ts,cid) VALUES(?,?,?,?,?,?)",
                (m[1], m[0], iv, ct, int(time.time()), cid))
        except sqlite3.IntegrityError:
            existing = db.execute("SELECT id FROM messages WHERE group_id=? AND cid=?", (m[1], cid)).fetchone() \
                       if cid else None
            if existing: return self.send(200, {"ok": True, "id": existing[0], "idempotent": True})
            return self.send(500, {"error": "server error"})
        ws_broadcast(m[1], "new")
        self.send(200, {"ok": True, "id": cur.lastrowid})

    def rotate_token(self):
        m = self.member()
        if not m: return self.send(401, {"error": "unauthorized"})
        new = secrets.token_urlsafe(32)
        try:
            with tx():
                db.execute(
                    "UPDATE members SET token_h_prev=token_h, token_h_prev_ts=?, token_h=? WHERE id=?",
                    (int(time.time()), sha(new), m[0]))
        except Exception as e:
            log_json(level="error", msg="rotate-token failed", error=str(e))
            return self.send(500, {"error": "server error"})
        audit(m[1], m[0], "token-rotate")
        self.send(200, {"token": new})

    def upload(self, ip, query):
        th = sha(self.headers.get("X-Token",""))[:16]
        if limited(ip, "up", 300) or limited(th, "up", 600): return self.send(429, {"error": "slow down"})
        m = self.member()
        if not m: return self.send(401, {"error": "unauthorized"})
        _, rot = db.execute("SELECT epoch,rot FROM group_state WHERE group_id=?", (m[1],)).fetchone() or (0,0)
        if rot: return self.send(409, {"error": "key rotation pending"})
        q = parse_qs(query)
        try: fid, idx, total = q["fid"][0], int(q["idx"][0]), int(q["total"][0])
        except (KeyError, ValueError): return self.send(400, {"error": "bad request"})
        vis = (q.get("vis", ["all"])[0] or "all").lower()
        if vis not in _ALLOWED_VIS: vis = "all"
        chunk_hash = (q.get("h", [""])[0] or "").lower()
        if REQUIRE_CHUNK_HASH and not is_hex64(chunk_hash):
            return self.send(400, {"error": "missing chunk hash (h=<sha256 hex>)"})
        if chunk_hash and not is_hex64(chunk_hash):
            return self.send(400, {"error": "invalid chunk hash format"})
        n = int(self.headers.get("Content-Length") or 0)
        if not (re.fullmatch(r"[0-9a-f]{32}", fid) and 1 <= total <= MAX_CHUNKS and 0 <= idx < total):
            return self.send(400, {"error": "bad request"})
        if not 28 < n <= CHUNK_MAX: return self.send(413, {"error": "bad chunk size"})
        if not has_disk_space(n + 10 * 1024 * 1024):
            return self.send(507, {"error": "server disk full, try again later"})
        if not _upload_sem.acquire(blocking=False):
            return self.send(503, {"error": "too many concurrent uploads, try again shortly"})
        try:
            try: data = self._read_body_bytes(n, UPLOAD_TIMEOUT)
            except (TimeoutError, OSError):
                return self.send(408, {"error": "upload read timeout or truncation"})
            if len(data) != n: return self.send(400, {"error": "truncated"})
            if REQUIRE_CHUNK_HASH or chunk_hash:
                computed = hashlib.sha256(data).hexdigest()
                if not hmac.compare_digest(computed, chunk_hash):
                    log_json(level="warn", msg="chunk hash mismatch", fid=fid[:8], idx=idx)
                    return self.send(400, {"error": "chunk integrity check failed"})
            if idx == 0:
                try:
                    with tx():
                        row = db.execute(
                            "SELECT group_id,member_id,total,vis,published FROM files WHERE fid=?",
                            (fid,)).fetchone()
                        if row is None:
                            reserved_total = total * CHUNK_MAX
                            used = db.execute(
                                "SELECT COALESCE(SUM(bytes + reserved),0) FROM files WHERE group_id=?",
                                (m[1],)).fetchone()[0]
                            if used + reserved_total > GROUP_QUOTA: raise _QuotaExceeded()
                            now = int(time.time())
                            db.execute(
                                "INSERT INTO files(fid,group_id,member_id,total,bytes,reserved,ts,vis,first_seen) "
                                "VALUES(?,?,?,?,0,?,?,?,?)",
                                (fid, m[1], m[0], total, reserved_total, now, vis, now))
                        elif row[0] != m[1] or row[1] != m[0] or row[2] != total:
                            raise _Forbidden()
                        elif (row[3] or "all") != vis:
                            return self.send(409, {"error": "visibility changed, restart upload"})
                except _QuotaExceeded:
                    return self.send(507, {"error": "storage quota exceeded (including in-progress reservations)"})
                except _Forbidden:
                    return self.send(403, {"error": "forbidden"})
            else:
                row = db.execute(
                    "SELECT group_id,member_id,total FROM files WHERE fid=?", (fid,)).fetchone()
                if not row or row[0] != m[1] or row[1] != m[0] or row[2] != total:
                    return self.send(403, {"error": "forbidden"})
            d = os.path.join(FILES, m[1])
            os.makedirs(d, mode=0o700, exist_ok=True)
            try: os.chmod(d, 0o700)
            except OSError: pass
            chunk_path = os.path.join(d, f"{fid}.{idx}")
            tmp_path = chunk_path + ".tmp"
            try:
                with open(tmp_path, "wb") as fh_:
                    written = fh_.write(data); fh_.flush()
                    try: os.fsync(fh_.fileno())
                    except (AttributeError, OSError): pass
                if written != n: raise OSError(f"short write: {written}/{n}")
                os.replace(tmp_path, chunk_path)
                try:
                    dfd = os.open(d, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
                    try: os.fsync(dfd)
                    finally: os.close(dfd)
                except OSError: pass
                try: os.chmod(chunk_path, 0o600)
                except OSError: pass
            except OSError as e:
                try: os.remove(tmp_path)
                except OSError: pass
                log_json(level="error", msg="upload write failed", error=str(e))
                return self.send(507, {"error": "server disk write failed, try again"})
            try:
                with tx():
                    fr = db.execute(
                        "SELECT bytes, published FROM files WHERE fid=?", (fid,)).fetchone()
                    if fr and fr[1]:
                        old_hash = db.execute(
                            "SELECT sha256 FROM file_chunks WHERE fid=? AND idx=?",
                            (fid, idx)).fetchone()
                        if old_hash and old_hash[0] != chunk_hash:
                            return self.send(409, {"error": "chunk already finalized"})
                    old = db.execute(
                        "SELECT bytes FROM file_chunks WHERE fid=? AND idx=?",
                        (fid, idx)).fetchone()
                    was_new = old is None
                    old_bytes = old[0] if old else 0
                    db.execute(
                        "INSERT OR REPLACE INTO file_chunks(fid,idx,sha256,bytes) VALUES(?,?,?,?)",
                        (fid, idx, chunk_hash, n))
                    if was_new:
                        db.execute(
                            "UPDATE files SET bytes=bytes+?, reserved=MAX(0, reserved-?) WHERE fid=?",
                            (n, CHUNK_MAX, fid))
                    else:
                        db.execute(
                            "UPDATE files SET bytes=bytes-?+? WHERE fid=?",
                            (old_bytes, n, fid))
                    have = db.execute("SELECT COUNT(*) FROM file_chunks WHERE fid=?", (fid,)).fetchone()[0]
                    if have == total:
                        db.execute("UPDATE files SET reserved=0, published=1, ts=? WHERE fid=?",
                                   (int(time.time()), fid))
                    else:
                        db.execute("UPDATE files SET ts=? WHERE fid=?", (int(time.time()), fid))
            except sqlite3.Error as e:
                log_json(level="error", msg="upload db update failed", error=str(e))
                return self.send(500, {"error": "server error"})
            self.send(200, {"ok": True})
        finally:
            _upload_sem.release()

    def download(self, query):
        m = self.member()
        if not m: return self.send(401, {"error": "unauthorized"})
        if limited(m[0], "dl", 600): return self.send(429, {"error": "slow down"})
        q = parse_qs(query)
        try: fid, idx = q["fid"][0], int(q["idx"][0])
        except (KeyError, ValueError): return self.send(400, {"error": "bad request"})
        is_dl = q.get("download", ["0"])[0] == "1"
        row = db.execute("SELECT group_id,total,member_id,vis,published FROM files WHERE fid=?", (fid,)).fetchone() \
              if re.fullmatch(r"[0-9a-f]{32}", fid) else None
        if not row or row[0] != m[1] or not 0 <= idx < row[1]:
            return self.send(404, {"error": "not found"})
        if not row[4]:
            return self.send(404, {"error": "file not yet fully uploaded"})
        vis = row[3] or "all"
        if is_dl:
            if not can_download(m, row[2], vis, get_policy(m[1])):
                if vis == "self":  return self.send(403, {"error": "only the uploader can download this file"})
                if vis == "view":  return self.send(403, {"error": "this file is view-only (no download)"})
                return self.send(403, {"error": "downloads are restricted by the admin"})
        else:
            if not can_view(m, row[2], vis):
                return self.send(403, {"error": "only the uploader can view this file"})
        chunk_path = os.path.join(FILES, m[1], f"{fid}.{idx}")
        try:
            with open(chunk_path, "rb") as fh_: data = fh_.read()
        except FileNotFoundError:
            return self.send(410, {"error": "This file's data was lost on the server. Please re-upload."})
        except OSError as e:
            log_json(level="error", msg="download read failed", error=str(e))
            return self.send(500, {"error": "server could not read file"})
        hdr = None
        row_h = db.execute("SELECT sha256 FROM file_chunks WHERE fid=? AND idx=?", (fid, idx)).fetchone()
        if row_h and row_h[0]: hdr = {"X-Chunk-SHA256": row_h[0]}
        self.send(200, data, "application/octet-stream", extra_headers=hdr)

    def state(self):
        m = self.member()
        if not m: return self.send(401, {"error": "unauthorized"})
        if limited(m[0], "state", 20): return self.send(429, {"error": "slow down"})
        g = m[1]
        ep, rot = db.execute("SELECT epoch,rot FROM group_state WHERE group_id=?", (g,)).fetchone() or (0,0)
        raw_mem = db.execute(
            "SELECT id,role,pub,pub_sig FROM members WHERE group_id=? ORDER BY joined", (g,)).fetchall()
        verified_mem = []
        for r in raw_mem:
            mid, role, pub_json, pub_sig = r[0], r[1], r[2], r[3]
            if not pub_sig or not hmac.compare_digest(pub_hmac(mid, pub_json), pub_sig):
                log_json(level="warn", msg="pub_sig mismatch", mid=mid[:8])
                continue
            try: pub = json.loads(pub_json)
            except Exception: continue
            verified_mem.append(dict(id=mid, role=role, pub=pub))
        wr = db.execute("SELECT epoch,from_id,blob FROM wraps WHERE member_id=? ORDER BY epoch", (m[0],)).fetchall()
        have = {r[0] for r in db.execute("SELECT member_id FROM wraps WHERE group_id=? AND epoch=?", (g, ep))}
        miss = [r["id"] for r in verified_mem
                if ep > 0 and r["id"] not in have and _has_good_dh(r["pub"])] if m[2] == "admin" else []
        self.send(200, {"epoch": ep, "rot": rot, "missing": miss, "online": ws_online(g),
                        "name": get_name(g),
                        "file_policy": get_policy(g),
                        "members": verified_mem,
                        "wraps": [{"epoch": r[0], "from": r[1], "blob": r[2]} for r in wr]})

    def _wraps_ok(self, d):
        w = d.get("wraps")
        ok = isinstance(w, list) and 0 < len(w) <= 200 and all(
            isinstance(x, dict) and isinstance(x.get("member_id"), str)
            and isinstance(x.get("blob"), str) and 0 < len(x["blob"]) <= 256 for x in w)
        return w if ok else None

    def rotate(self, d):
        m = self.admin()
        if not m: return
        w, new = self._wraps_ok(d), d.get("epoch")
        if not w or not isinstance(new, int): return self.send(400, {"error": "bad request"})

        # Idempotency: another admin/tab already committed this epoch.
        # Return success WITHOUT touching wraps — the caller re-fetches state
        # and unwraps the winner's key. Prevents "double rotate" from
        # silently overwriting the first admin's key.
        pre_cur = (db.execute(
            "SELECT epoch FROM group_state WHERE group_id=?", (m[1],)).fetchone() or (0,))[0]
        if new == pre_cur:
            log_json(level="info", msg="rotate idempotent noop",
                     gid=m[1][:8], epoch=new)
            return self.send(200, {"ok": True, "already": True, "epoch": pre_cur})

        try:
            with tx():
                cur = (db.execute("SELECT epoch FROM group_state WHERE group_id=?", (m[1],)).fetchone() or (0,))[0]
                if new == cur:
                    return self.send(200, {"ok": True, "already": True, "epoch": cur})
                if new != cur + 1: raise ValueError("epoch")
                rows = db.execute("SELECT id,pub FROM members WHERE group_id=?", (m[1],)).fetchall()
                need = set()
                for r in rows:
                    try: pub = json.loads(r[1])
                    except Exception: continue
                    if _has_good_dh(pub): need.add(r[0])
                allm = {r[0] for r in rows}
                got = {x["member_id"] for x in w}
                if not need <= got or not got <= allm: raise ValueError("wraps")
                for x in w:
                    db.execute("INSERT OR REPLACE INTO wraps(member_id,epoch,group_id,from_id,blob) "
                               "VALUES(?,?,?,?,?)", (x["member_id"], new, m[1], m[0], x["blob"]))
                db.execute("INSERT INTO group_state(group_id,epoch,rot) VALUES(?,?,0) "
                           "ON CONFLICT(group_id) DO UPDATE SET epoch=?, rot=0", (m[1], new, new))
        except ValueError: return self.send(409, {"error": "epoch changed, retry"})
        audit(m[1], m[0], "rotate", f"epoch-{new}")
        ws_broadcast(m[1], "refresh"); self.send(200, {"ok": True, "epoch": new})

    def wrap(self, d):
        m = self.admin()
        if not m: return
        w = self._wraps_ok(d)
        if not w: return self.send(400, {"error": "bad request"})
        try:
            with tx():
                cur = (db.execute("SELECT epoch FROM group_state WHERE group_id=?", (m[1],)).fetchone() or (0,))[0]
                if d.get("epoch") != cur: return self.send(409, {"error": "epoch changed, retry"})
                allm = {r[0] for r in db.execute("SELECT id FROM members WHERE group_id=?", (m[1],)).fetchall()}
                for x in w:
                    if x["member_id"] in allm:
                        db.execute("INSERT OR IGNORE INTO wraps(member_id,epoch,group_id,from_id,blob) "
                                   "VALUES(?,?,?,?,?)", (x["member_id"], cur, m[1], m[0], x["blob"]))
        except Exception as e:
            log_json(level="error", msg="wrap failed", error=str(e))
            return self.send(500, {"error": "server error"})
        ws_broadcast(m[1], "refresh"); self.send(200, {"ok": True})

    def admin(self):
        m = self.member()
        if not m or m[2] != "admin": self.send(403, {"error": "admin only"}); return None
        return m

    def set_policy(self, d):
        m = self.admin()
        if not m: return
        p = d.get("policy")
        if p not in _ALLOWED_POLICIES:
            return self.send(400, {"error": "invalid policy (admin|owner|everyone)"})
        db.execute("UPDATE groups SET file_policy=? WHERE id=?", (p, m[1]))
        audit(m[1], m[0], "policy", p)
        ws_broadcast(m[1], "refresh")
        log_json(level="info", msg="policy changed", gid=m[1][:8], policy=p)
        self.send(200, {"ok": True, "policy": p})

    def rename(self, d):
        m = self.admin()
        if not m: return
        name = d.get("name")
        if not isinstance(name, str):
            return self.send(400, {"error": "invalid name"})
        name = name.strip()
        if len(name) < 1 or len(name) > 60:
            return self.send(400, {"error": "group name must be 1–60 characters"})
        db.execute("UPDATE groups SET name=? WHERE id=?", (name, m[1]))
        audit(m[1], m[0], "rename", name[:32])
        ws_broadcast(m[1], "refresh")
        log_json(level="info", msg="group renamed", gid=m[1][:8])
        self.send(200, {"ok": True, "name": name})

    def change_credentials(self, d):
        m = self.admin()
        if not m: return

        curr_v    = d.get("current_admin_v")
        curr_gid  = d.get("current_gid")
        new_gid   = d.get("new_gid")
        new_inv_v = d.get("new_inv_v")
        new_adm_v = d.get("new_adm_v")
        new_name  = d.get("new_name")
        new_pol   = d.get("new_policy")

        if not is_hex64(curr_v):
            return self.send(400, {"error": "invalid request"})

        row = db.execute(
            "SELECT admin_v, gid_hash, invite_v, name, file_policy FROM groups WHERE id=?",
            (m[1],)).fetchone()
        if not row:
            return self.send(404, {"error": "group not found"})
        stored_admin_v, stored_gid_hash, stored_inv_v, stored_name, stored_pol = row
        stored_name = stored_name or ""
        stored_pol  = stored_pol or FILE_DOWNLOAD_POLICY

        if curr_gid is not None:
            if not (isinstance(curr_gid, list) and len(curr_gid) == 8 and set(curr_gid) <= WSET):
                return self.send(400, {"error": "invalid current Group ID format"})
            if not hmac.compare_digest(gid_hash(curr_gid), stored_gid_hash):
                log_json(level="warn", msg="cred change: wrong current gid",
                         gid=m[1][:8], mid=m[0][:8])
                return self.send(403, {"error": "current Group ID is incorrect"})

        if not hmac.compare_digest(sha(curr_v), stored_admin_v):
            log_json(level="warn", msg="cred change: bad admin key",
                     gid=m[1][:8], mid=m[0][:8])
            return self.send(403, {"error": "current Admin Key is incorrect"})

        changed_gid = new_gid is not None
        changed_inv = new_inv_v is not None
        changed_adm = new_adm_v is not None
        changed_name = new_name is not None and str(new_name).strip() != stored_name
        changed_pol  = new_pol is not None and new_pol != stored_pol

        if not (changed_gid or changed_inv or changed_adm or changed_name or changed_pol):
            return self.send(400, {"error": "nothing to change"})

        if changed_gid:
            if not (isinstance(new_gid, list) and len(new_gid) == 8 and set(new_gid) <= WSET):
                return self.send(400, {"error": "new Group ID must be 8 words"})
            if not (changed_inv and changed_adm):
                return self.send(400, {"error":
                    "changing Group ID requires new Invite Key and Admin Key "
                    "(their verification hashes embed the Group ID)"})

        if changed_inv and not is_hex64(new_inv_v):
            return self.send(400, {"error": "invalid new Invite Key hash"})
        if changed_adm and not is_hex64(new_adm_v):
            return self.send(400, {"error": "invalid new Admin Key hash"})
        if changed_name:
            stripped = str(new_name).strip()
            if len(stripped) < 1 or len(stripped) > 60:
                return self.send(400, {"error": "group name must be 1–60 characters"})
            new_name = stripped
        if changed_pol and new_pol not in _ALLOWED_POLICIES:
            return self.send(400, {"error": "invalid download policy"})

        new_gid_hash = gid_hash(new_gid) if changed_gid else stored_gid_hash
        new_inv_hash = sha(new_inv_v)   if changed_inv else stored_inv_v
        new_adm_hash = sha(new_adm_v)   if changed_adm else stored_admin_v

        if new_gid_hash != stored_gid_hash:
            collision = db.execute(
                "SELECT id FROM groups WHERE gid_hash=? AND id!=?",
                (new_gid_hash, m[1])).fetchone()
            if collision:
                return self.send(409, {"error":
                    "that Group ID is already in use — pick different words"})

        updates, params = [], []
        if new_gid_hash != stored_gid_hash:
            updates.append("gid_hash=?");  params.append(new_gid_hash)
        if new_inv_hash != stored_inv_v:
            updates.append("invite_v=?");  params.append(new_inv_hash)
        if new_adm_hash != stored_admin_v:
            updates.append("admin_v=?");   params.append(new_adm_hash)
        if changed_name:
            updates.append("name=?");      params.append(new_name)
        if changed_pol:
            updates.append("file_policy=?"); params.append(new_pol)
        params.append(m[1])

        rotating = (new_gid_hash != stored_gid_hash) or (new_inv_hash != stored_inv_v)
        try:
            with tx():
                db.execute(f"UPDATE groups SET {', '.join(updates)} WHERE id=?",
                           tuple(params))
                if rotating:
                    db.execute(
                        "INSERT INTO group_state(group_id,epoch,rot) VALUES(?,0,1) "
                        "ON CONFLICT(group_id) DO UPDATE SET rot=1", (m[1],))
        except Exception as e:
            log_json(level="error", msg="cred change failed", error=str(e))
            return self.send(500, {"error": "server error"})

        kind = ("gid" if changed_gid else
                "invite" if changed_inv else
                "admin" if changed_adm else
                "name" if changed_name else "policy")
        audit(m[1], m[0], "cred-change", kind)
        ws_broadcast(m[1], "refresh")
        log_json(level="info", msg="credentials changed", gid=m[1][:8], kind=kind,
                 changed_gid=changed_gid, changed_inv=changed_inv,
                 changed_adm=changed_adm, changed_name=changed_name,
                 changed_pol=changed_pol, rotating=rotating)
        self.send(200, {
            "ok": True,
            "rotating": rotating,
            "name": new_name if changed_name else stored_name,
            "file_policy": new_pol if changed_pol else stored_pol,
        })

    def admin_members(self):
        m = self.admin()
        if not m: return
        mem = db.execute("""SELECT m.id,m.fp,m.role,m.joined,
                              (SELECT COUNT(*) FROM messages x WHERE x.member_id=m.id)
                              FROM members m WHERE m.group_id=? ORDER BY m.joined""", (m[1],)).fetchall()
        bl = db.execute("SELECT fp,ts FROM blocks WHERE group_id=? ORDER BY ts DESC", (m[1],)).fetchall()
        online = set(ws_online(m[1]))
        self.send(200, {
            "members": [dict(id=r[0], fp=r[1], role=r[2], joined=r[3], msgs=r[4], online=(r[0] in online)) for r in mem],
            "blocked": [dict(fp=r[0], ts=r[1]) for r in bl],
            "file_policy": get_policy(m[1]),
            "name": get_name(m[1])})

    def admin_events(self):
        m = self.admin()
        if not m: return
        rows = db.execute("SELECT kind,target_fp,ts FROM events WHERE group_id=? ORDER BY id DESC LIMIT 50", (m[1],)).fetchall()
        self.send(200, {"events": [dict(kind=r[0], target_fp=r[1], ts=r[2]) for r in rows]})

    def remove(self, d, block):
        m = self.admin()
        if not m: return
        mid = d.get("member_id")
        t = db.execute("SELECT id,fp,role FROM members WHERE id=? AND group_id=?", (mid, m[1])).fetchone() \
            if isinstance(mid, str) else None
        if not t: return self.send(404, {"error": "member not found"})
        if t[2] == "admin": return self.send(403, {"error": "admins cannot be removed"})
        fids = [r[0] for r in db.execute("SELECT fid FROM files WHERE member_id=? AND group_id=?", (t[0], m[1])).fetchall()] \
               if d.get("wipe") else []
        with lock:
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute("DELETE FROM members WHERE id=?", (t[0],))
                db.execute("DELETE FROM wraps WHERE member_id=?", (t[0],))
                db.execute("INSERT INTO group_state(group_id,epoch,rot) VALUES(?,0,1) "
                           "ON CONFLICT(group_id) DO UPDATE SET rot=1", (m[1],))
                if block:
                    db.execute("INSERT OR IGNORE INTO blocks(group_id,fp,ts) VALUES(?,?,?)",
                               (m[1], t[1], int(time.time())))
                if d.get("wipe"):
                    db.execute("DELETE FROM messages WHERE member_id=? AND group_id=?", (t[0], m[1]))
                    db.execute("DELETE FROM files WHERE member_id=? AND group_id=?", (t[0], m[1]))
                db.execute("COMMIT")
            except Exception:
                try: db.execute("ROLLBACK")
                except sqlite3.Error: pass
                log_json(level="error", msg="remove failed", error=traceback.format_exc())
                return self.send(500, {"error": "could not remove"})
        audit(m[1], m[0], "block" if block else "kick", t[1])
        for fid in fids:
            if re.fullmatch(r"[0-9a-f]{32}", fid):
                for i in range(MAX_CHUNKS):
                    try: os.remove(os.path.join(FILES, m[1], f"{fid}.{i}"))
                    except OSError: pass
        ws_close_member(m[1], t[0]); broadcast_presence(m[1]); ws_broadcast(m[1], "refresh")
        self.send(200, {"ok": True})

    def unblock(self, d):
        m = self.admin()
        if not m: return
        fp = d.get("fp")
        if not isinstance(fp, str) or not (1 <= len(fp) <= 32):
            return self.send(400, {"error": "bad request"})
        db.execute("DELETE FROM blocks WHERE group_id=? AND fp=?", (m[1], fp))
        audit(m[1], m[0], "unblock", fp); self.send(200, {"ok": True})

    def delete_group(self, d):
        m = self.admin()
        if not m: return
        if d.get("confirm") != "DELETE": return self.send(400, {"error": "type DELETE to confirm"})
        gid = m[1]
        with lock:
            db.execute("BEGIN IMMEDIATE")
            try:
                for t in ("messages","files","blocks","wraps","group_state","members","events"):
                    db.execute(f"DELETE FROM {t} WHERE group_id=?", (gid,))
                db.execute("DELETE FROM groups WHERE id=?", (gid,))
                db.execute("COMMIT")
            except Exception:
                try: db.execute("ROLLBACK")
                except sqlite3.Error: pass
                log_json(level="error", msg="delete group failed", error=traceback.format_exc())
                return self.send(500, {"error": "could not delete group"})
        ws_close_group(gid)
        shutil.rmtree(os.path.join(FILES, gid), ignore_errors=True)
        issues = verify_group_cleanup(gid)
        self.send(200, {"ok": True, "clean": not issues, "issues": issues})

    def purge(self, d):
        m = self.admin()
        if not m: return self.send(403, {"error": "admin only"})
        with tx():
            db.execute("DELETE FROM messages WHERE group_id=?", (m[1],))
            db.execute("DELETE FROM files WHERE group_id=?", (m[1],))
        shutil.rmtree(os.path.join(FILES, m[1]), ignore_errors=True)
        audit(m[1], m[0], "purge"); ws_broadcast(m[1], "purge")
        self.send(200, {"ok": True})


# ---------- Backup / restore verification CLI ----------
def _verify_restored(db_path, pepper_path, hmac_path):
    problems = []
    peppers = {}
    current = None
    try:
        with open(pepper_path, "rb") as f:
            j = json.load(f)
        peppers = {int(k): bytes.fromhex(v) for k, v in j["peppers"].items()}
        current = int(j["current"])
        if current not in peppers:
            problems.append(f"pepper: current v{current} missing from pepper set")
        if not peppers:
            problems.append("pepper: empty pepper set")
    except Exception as e:
        problems.append(f"pepper: cannot load ({e})")
    hmac_key = b""
    try:
        with open(hmac_path, "rb") as f:
            hmac_key = f.read()
        if len(hmac_key) != 32:
            problems.append(f"hmac_key: expected 32 bytes, got {len(hmac_key)}")
    except Exception as e:
        problems.append(f"hmac_key: cannot read ({e})")
    if problems:
        return problems
    try:
        con = sqlite3.connect(db_path)
        bad_sig = 0; total_sig = 0
        for mid, pub_json, pub_sig in con.execute(
                "SELECT id, pub, pub_sig FROM members"):
            total_sig += 1
            expect = hmac.new(hmac_key, f"{mid}:{pub_json}".encode(),
                              hashlib.sha256).hexdigest()
            if not pub_sig or not hmac.compare_digest(expect, pub_sig):
                bad_sig += 1
        if total_sig and bad_sig:
            problems.append(
                f"pub_sig: {bad_sig}/{total_sig} mismatches — DB and hmac_key are inconsistent")
        try:
            n_groups = con.execute("SELECT COUNT(*) FROM groups").fetchone()[0]
        except sqlite3.Error:
            n_groups = 0
        con.close()
        if n_groups and not total_sig:
            problems.append("members: groups exist but members table is empty")
    except sqlite3.Error as e:
        problems.append(f"db: cannot open/query ({e})")
    return problems


def _cli_backup(dest):
    import tempfile, shutil as _sh
    src_db_path    = DBPATH
    src_pep_path   = PEPPER_FILE
    src_hmac_path  = HMAC_KEY_FILE
    os.makedirs(dest, mode=0o700, exist_ok=True)
    _harden(dest, 0o700)
    ts = time.strftime("%Y%m%dT%H%M%S")
    snap_db   = os.path.join(dest, f"chat-{ts}.db")
    snap_pep  = os.path.join(dest, f"pepper-{ts}.json")
    snap_hmac = os.path.join(dest, f"hmac_key-{ts}")
    manifest  = os.path.join(dest, f"manifest-{ts}.json")
    src = sqlite3.connect(src_db_path)
    dst = sqlite3.connect(snap_db)
    try:
        with dst:
            src.backup(dst)
    finally:
        src.close()
        dst.close()
    _sh.copyfile(src_pep_path,  snap_pep)
    _sh.copyfile(src_hmac_path, snap_hmac)
    for p in (snap_db, snap_pep, snap_hmac):
        _harden(p, 0o600)
    with tempfile.TemporaryDirectory() as td:
        tdb  = os.path.join(td, "chat.db");   _sh.copyfile(snap_db,   tdb)
        tpep = os.path.join(td, "pepper");    _sh.copyfile(snap_pep,  tpep)
        thm  = os.path.join(td, "hmac_key");  _sh.copyfile(snap_hmac, thm)
        problems = _verify_restored(tdb, tpep, thm)
        if problems:
            log_json(level="error", msg="backup verification failed",
                     dest=dest, problems=problems)
            raise SystemExit(
                "backup verification FAILED:\n  - " + "\n  - ".join(problems))
    def _sha256(p):
        h = hashlib.sha256()
        with open(p, "rb") as f:
            for b in iter(lambda: f.read(1 << 20), b""):
                h.update(b)
        return h.hexdigest()
    json.dump({
        "created": ts,
        "artifacts": {
            "chat.db":  {"sha256": _sha256(snap_db),   "bytes": os.path.getsize(snap_db)},
            "pepper":   {"sha256": _sha256(snap_pep),  "bytes": os.path.getsize(snap_pep)},
            "hmac_key": {"sha256": _sha256(snap_hmac), "bytes": os.path.getsize(snap_hmac)},
        },
        "note": "chat.db is only meaningful together with pepper and hmac_key; restore all three.",
    }, open(manifest, "w"), indent=2)
    _harden(manifest, 0o600)
    log_json(level="info", msg="backup verified", dest=dest, manifest=manifest)
    print(f"OK — verified backup at {dest}")
    print(f"     manifest: {manifest}")


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--backup":
        _cli_backup(sys.argv[2]); sys.exit(0)
    port = int(os.environ.get("PORT", 8000))
    bind_host = os.environ.get("BIND_HOST", "127.0.0.1")
    if bind_host != "127.0.0.1":
        log_json(level="warn", msg="BIND_HOST not localhost", host=bind_host)
    if TRUST_PROXY:
        log_json(level="warn", msg="TRUST_PROXY=1 — only trusted reverse proxy should reach this port")
    srv = ThreadingHTTPServer((bind_host, port), H)
    c, k = os.path.join(ROOT, "cert.pem"), os.path.join(ROOT, "key.pem")
    if os.path.exists(c) and os.path.exists(k):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(c, k)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
        USE_HTTPS[0] = True
    def _shutdown(signum, frame):
        log_json(level="info", msg="shutdown signal", signal=signum)
        with ws_lock:
            all_conns = [(gid, set(conns)) for gid, conns in ws_clients.items()]
        for gid, conns in all_conns:
            for c_ in conns:
                try: c_.close(1001)
                except Exception: pass
        time.sleep(0.5)
        threading.Thread(target=srv.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT,  _shutdown)
    log_json(level="info", msg="server starting",
             proto="https" if USE_HTTPS[0] else "http",
             host=bind_host, port=port,
             retention_days=RETENTION_DAYS,
             policy=FILE_DOWNLOAD_POLICY,
             pepper=PEPPER_CURRENT,
             proxy=TRUST_PROXY,
             max_ws_per_ip=MAX_WS_PER_IP)
    try: srv.serve_forever()
    except KeyboardInterrupt: pass
